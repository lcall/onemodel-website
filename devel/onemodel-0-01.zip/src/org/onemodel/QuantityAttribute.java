/*
    Copyright (c) 2002-2003, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

/** Represents one quantity object in the system (usually [always, as of 9/2002] used as an attribute on a Entity). 
 */
public class QuantityAttribute {
    
    /** This constructor instantiates an existing object from the DB. You can use Entity.addQuantityAttribute() to 
        create a new object. 
    */
    QuantityAttribute(long inId, Database inDB) throws Exception {
        if (inDB.quantityAttributeKeyExists(inId)) {
            mDB = inDB;
            mId = inId;
        } else {
            throw new Exception("Key "+inId+" does not exist in database."); // DON'T CHANGE this msg unless you also change the trap for it, if used, in other code.
        }
    }
    
    /** return smthg like "volume: 15.1 liters". 
    */
    static String getDisplayString(long inQuantityId, Model inModel, Database inDB) throws Exception {
        QuantityAttribute q = new QuantityAttribute(inQuantityId,inDB);
        String typeName = inModel.getObjectName(q.getAttrTypeId());
        float number = q.getNumber();
        long unitId = q.getUnitId();
        return typeName+": "+number + " "+inModel.getObjectName(unitId);
    }
    
    float getNumber() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mNumber;
    }
    long getUnitId() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mUnitId;
    }
    long getId() { return mId; } 
    long getParentId() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mParentId;
    }
    long getAttrTypeId() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mAttrTypeId;
    }
    long getValidOnDate() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mValidOnDate;
    }
    long getObservationDate() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mObservationDate;
    }
    
    private void readDataFromDB() throws Exception {
        java.util.ArrayList quantityData = mDB.getQuantityAttributeData(mId);
        
        mParentId=((Long)quantityData.get(0)).longValue();
        mUnitId=((Long)quantityData.get(1)).longValue();
        mNumber = ((Float)quantityData.get(2)).floatValue();
        mAttrTypeId=((Long)quantityData.get(3)).longValue();
        mValidOnDate=((Long)quantityData.get(4)).longValue();
        mObservationDate=((Long)quantityData.get(5)).longValue();
        
        mAlreadyReadData=true;
    }

    
    /** Removes this object from the system. */
    void delete() throws Exception {
        mDB.deleteQuantityAttribute(mId);
    }
    
    private Database mDB;
    private boolean mAlreadyReadData=false;
    
    /** For descriptions of the meanings of these variables, see the comments 
        on PostgreSQLDatabase.createQuantityAttribute(...).
    */
    private long mParentId;
    private long mId; // the unique identifier assigned to this object in the database.
    private long mUnitId;
    private float mNumber;
    private long mAttrTypeId;
    private long mValidOnDate;
    private long mObservationDate;
}
