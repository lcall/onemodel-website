/*
    Copyright (c) 2002-2003, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

import junit.framework.*;

public class AllTests {

    public static Test suite() {

        TestSuite suite = new TestSuite();

        suite.addTest(QuantityAttributeTest.suite());
        suite.addTest(PostgreSQLDatabaseTest.suite());
        suite.addTest(ModelTest.suite());
        suite.addTest(EntityTest.suite());
		
        return suite;
    }

    public static void main(String args[]) {
        junit.textui.TestRunner.run(suite());
    }
}

