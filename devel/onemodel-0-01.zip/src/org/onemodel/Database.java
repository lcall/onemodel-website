/*
    Copyright (c) 2002-2003, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

import java.sql.*;

/** 
    Interface that defines which methods should be implemented when employing a
    new storage back-end. I.e., any code that would change when we change 
    storage systems (like from postgresql to an object database or who knows), 
    goes in a subclass of this interface.
    <br><br>
    Note that any changes to the database structures (or constraints, etc) for any
    subclasses of this interface should 
    ALWAYS have the following: <ul>
    <li>Constraints, rules, functions, stored procedures, or triggers
    or something to enforce data integrity and referential integrity at the database level, 
    whenever possible. When this is impossible, it should be discussed on the developer mailing 
    so that we can consider putting it in the right place in the code, with the goal of 
    greatest simplicity and reliability.</li>
    <li>Put these things in the auto-creation steps of the DB class. See createDatabase() and createTables().</li>
    <li>Add comments to that part of the code, explaining the change or requirement, as needed.</li>
    <li>Any changes (as anywhere in this system) should be done in a test-first manner, for anything that
    could go wrong, along these lines:  First write a test that demonstrates the issue and fails, then 
    write code to correct the issue, then re-run the test to see the successful outcome. This helps keep our
    regression suite current, and could even help think through design issues without overcomplicating things. 
    </ul>
*/
interface Database {
    void connect(String inDbName) throws java.sql.SQLException;
    
    /** Does standard setup for a "OneModel" database, such as when starting up for the first time, or when creating a test system. */
    void createTables() throws java.sql.SQLException;
    
    /** Written with intent that this can be called when creating a play area for the test suite, so that production data is not disturbed. */
    void createDatabase(String inDbName) throws java.sql.SQLException;
        
    /** Saves data for a quantity attribute for a Entity (i.e., "6 inches length").<br>
        inParentId is the key of the Entity for which the info is being saved.<br>
        inUnitId represents a Entity; indicates the unit for this quantity (i.e., liters or inches).<br> 
        inNumber represents "how many" of the given unit.<br>
        inAttrTypeId represents the attribute type and also is a Entity (i.e., "volume" or "length")<br> 
        inValidOnDate represents the date on which this is asserted to be true (seems it would usually match the observation date); 
        (null means it is asserted true for all time.)<br>
        inObservationDate is the date the fact was observed. <br>
    */
    long /*id*/ createQuantityAttribute(long inParentId, long inUnitId, float inNumber, long inAttrTypeId, Long inValidOnDate, long inObservationDate) throws Exception;
    
    long /*id*/ createTextAttribute(long inParentId, String inText, long inAttrTypeId, Long inValidOnDate, long inObservationDate) throws Exception;
    
    long /*id*/ createEntity(String inName) throws Exception;
    
    void deleteEntity(long inID) throws Exception;
    
    void deleteQuantityAttribute(long inID) throws Exception;
    
    void deleteTextAttribute(long inID) throws Exception;
    
    /** Used, for example, when test code is finished with its test data. Be careful. */
    void destroyDatabase(String inDbName) throws java.sql.SQLException;
    
    /**  Max possible value for the "ID" data type, based on a specific implementation. */
    long getMaxIDValue();
    
    long getEntityCount() throws Exception;
    
    String getEntityName(long inID) throws Exception; 
    
    /** Currently returns as key the type ("quantity", "text", etc.) plus the unique ID, for uniqueness as a key in the map and 
        for convenience of storing the id in a simple place. Stores the attrTypeId thing in the value. Might be better to
        have an object that stores all three so maybe later we can do that.
    */
    java.util.SortedMap getEntityAttributeIdsAndAttributeTypeIds(long inID, long inStartingObjectIndex, long inMaxVals) throws Exception;
    
    long getAttrCount(long inID) throws Exception ;

    int getEntityNameLength();
    
    /** Allows querying for a range of objects in the database; returns a java.util.Map with keys and names. 
        1st parm is index to start with (0-based), 2nd parm is # of obj's to return.
    */
    java.util.TreeMap getEntities(long inStartingObjectIndex, int inMaxVals) throws Exception;

    long getQuantityAttributeCount(long inEntityId) throws Exception;
    
    long getTextAttributeCount(long inEntityId) throws Exception;
    
    java.util.ArrayList getQuantityAttributeData(long inQuantityId) throws Exception;
    
    java.util.ArrayList getTextAttributeData(long inTextId) throws Exception;

    boolean quantityAttributeKeyExists(long inID) throws Exception;
    
    boolean textAttributeKeyExists(long inID) throws Exception;
    
    boolean entityKeyExists(long inID) throws Exception;
    
    /** Indicates whether the database setup has been done. */
    boolean modelTablesExist() throws Exception;
    
    /** Like jdbc's default, if you don't call begin/rollback/commit, it should commit after every statementc; 
        but if you call begin/rollback/commit, it should let you manage explicitly and should automatically turn 
        autocommit on/off as needed to allow that. 
    */
    void beginTrans() throws java.sql.SQLException;
    void rollbackTrans() throws java.sql.SQLException;
    void commitTrans() throws java.sql.SQLException;
 }
