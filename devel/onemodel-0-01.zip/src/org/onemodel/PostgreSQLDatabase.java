/*
    Copyright (c) 2002-2003, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

import java.sql.*;

/** 
    Any code that would change when we change storage systems (like from postgresql to 
    an object database or who knows), goes in this class. Implements the Database 
    interface, allowing   
    <br><br>
    Note that any changes to the database structures (or constraints, etc) whatsoever should 
    ALWAYS have the following: <ul>
    <li>Constraints, rules, functions, stored procedures, or triggers
    or something to enforce data integrity and referential integrity at the database level, 
    whenever possible. When this is impossible, it should be discussed on the developer mailing 
    so that we can consider putting it in the right place in the code, with the goal of 
    greatest simplicity and reliability.</li>
    <li>Put these things in the auto-creation steps of the DB class. See createDatabase() and createTables().</li>
    <li>Add comments to that part of the code, explaining the change or requirement, as needed.</li>
    <li>Any changes (as anywhere in this system) should be done in a test-first manner, for anything that
    could go wrong, along these lines:  First write a test that demonstrates the issue and fails, then 
    write code to correct the issue, then re-run the test to see the successful outcome. This helps keep our
    regression suite current, and could even help think through design issues without overcomplicating things. 
    </ul>
*/
class PostgreSQLDatabase implements Database {
    /** Creates a new instance of Database. By default, auto-commit is on unless you explicitly open a transaction; then 
        auto-commit will be off until you rollbackTrans() or abortTrans(), at which point auto-commit is 
        turned back on. 
    */
    public PostgreSQLDatabase() throws Exception  {
        Class.forName("org.postgresql.Driver");
        connect("FirstModel");
        if (! modelTablesExist()) {
            createTables();
        }
    }
    
    public void connect(String inDbName) throws java.sql.SQLException {
        try {
            if (mConn!=null) { mConn.close(); }
        } catch (Exception e) {
            // todo: anything here? log it? notify someone to see why it happened?
        }
        
        mConn = DriverManager.getConnection("jdbc:postgresql:"+inDbName, "om",null);
        mConn.setTransactionIsolation(mConn.TRANSACTION_SERIALIZABLE);
    }
    
    /** Does standard setup for a "OneModel" database, such as when starting up for the first time, or when creating a test system. */
    public void createTables() throws java.sql.SQLException {
        Statement st=null;
        Statement st2=null;
        Statement st3=null;
        Statement st4=null;
        Statement st5=null;
        Statement st6=null;
        try {
            st = mConn.createStatement();
            String sql = "create sequence EntityKeySequence minvalue -9223372036854775808" ;
            st.executeUpdate(sql);
            
            st2 = mConn.createStatement();
            // id must be "unique not null" in ANY database used, because it is a primary key.
            sql = "create table Entity (name varchar(60) NOT NULL, id bigint DEFAULT nextval('EntityKeySequence') UNIQUE NOT NULL) WITHOUT OIDS";
            st2.executeUpdate(sql);
            
            st3 = mConn.createStatement();
            sql = "create sequence QuantityAttributeKeySequence minvalue -9223372036854775808" ;
            st3.executeUpdate(sql);
            
            st4 = mConn.createStatement();
            // the parent_id is the key for the object on which this quantity info is recorded; for other meanings see comments on
            // Entity.addQuantityAttribute(...).
            // id must be "unique not null" in ANY database used, because it is the primary key.
            sql = "create table QuantityAttribute (";
            sql += "parent_id bigint NOT NULL, ";
            sql += "id bigint DEFAULT nextval('QuantityAttributeKeySequence') UNIQUE NOT NULL, ";
            sql += "unit_id bigint NOT NULL, ";
            sql += "quantity_number double precision not null, ";
            sql += "attr_type_id bigint not null, ";
            sql += "valid_on_date bigint not null, ";
            sql += "observation_date bigint not null, ";
            sql += "CONSTRAINT valid_unit_id FOREIGN KEY (unit_id) REFERENCES entity (id), ";
            sql += "CONSTRAINT valid_attr_type_id FOREIGN KEY (attr_type_id) REFERENCES entity (id), ";
            sql += "CONSTRAINT valid_parent_id FOREIGN KEY (parent_id) REFERENCES entity (id) ON DELETE CASCADE ";
            //sql += "ON UPDATE CASCADE "; // here for good measure?, but no test written for it. Hopefully we wuoldn't be changing those keys anyway.  
            sql += ") ";
            sql += "WITHOUT OIDS ";
            st4.executeUpdate(sql);
            
            st5 = mConn.createStatement();
            sql = "create sequence TextAttributeKeySequence minvalue -9223372036854775808" ;
            st5.executeUpdate(sql);
            
            st6 = mConn.createStatement();
            // the parent_id is the key for the object on which this tet info is recorded; for other meanings see comments on
            // Entity.addQuantityAttribute(...).
            // id must be "unique not null" in ANY database used, because it is the primary key.
            sql = "create table TextAttribute (";
            sql += "parent_id bigint NOT NULL, ";
            sql += "id bigint DEFAULT nextval('TextAttributeKeySequence') UNIQUE NOT NULL, ";
            sql += "textValue text NOT NULL, ";
            sql += "attr_type_id bigint not null, ";
            sql += "valid_on_date bigint not null, ";
            sql += "observation_date bigint not null, ";
            sql += "CONSTRAINT valid_attr_type_id FOREIGN KEY (attr_type_id) REFERENCES entity (id), ";
            sql += "CONSTRAINT valid_parent_id FOREIGN KEY (parent_id) REFERENCES entity (id) ON DELETE CASCADE ";
            //sql += "ON UPDATE CASCADE "; // here for good measure?, but no test written for it. Hopefully we wuoldn't be changing those keys anyway.  
            sql += ") ";
            sql += "WITHOUT OIDS ";
            st6.executeUpdate(sql);
        } finally {
            if (st!=null) st.close();
            if (st2!=null) st2.close();
            if (st3!=null) st3.close();
            if (st4!=null) st4.close();
            if (st5!=null) st5.close();
            if (st6!=null) st6.close();
        }
    }
    
    /** Indicates whether the database setup has been done. */
    public boolean modelTablesExist() throws Exception {
        long rowcnt = countRows("select count(*) from pg_class where relname='entity'");
        boolean retval = false;
        if (rowcnt==1) {
            retval=true;
        } else if (rowcnt > 1) {
            throw new Exception("How can there be > 1 entries in pg_class where relname='entity'? ("+rowcnt+" found.)");
        }
        return retval;
    }        
    
    /** Used, for example, when test code is finished with its test data. Be careful. */
    public void destroyDatabase(String inDbName) throws java.sql.SQLException {
        Statement st=null;
        Statement st2=null;
        try {
            st = mConn.createStatement();
            String sql = "drop database "+inDbName ;
            st.executeUpdate(sql);
        } finally {
            if (st!=null) st.close();
        }
    }        
    
    /** Written with intent that this can be called when creating a play area for the test suite, so that production data is not disturbed. */
    public void createDatabase(String inDbName) throws java.sql.SQLException {
        Statement st=null;
        try {
            st = mConn.createStatement();
            String sql = "create database "+inDbName;
            st.executeUpdate(sql);
        } finally {
            if (st!=null) st.close();
        }
    }
        
    /** Saves data for a quantity attribute for a Entity (i.e., "6 inches length").<br>
        inParentId is the key of the Entity for which the info is being saved.<br>
        inUnitId represents a Entity; indicates the unit for this quantity (i.e., liters or inches).<br> 
        inNumber represents "how many" of the given unit.<br>
        inAttrTypeId represents the attribute type and also is a Entity (i.e., "volume" or "length")<br> 
        inValidOnDate represents the date on which this is asserted to be true (seems it would usually match the observation date); 
        null means it is asserted true for all time. inObservationDate is the date the fact was observed. <br>
        <br>
        We store the dates in
        postgresql (at least) as bigint which should be the same size as a java long, with the understanding that we are
        talking about java-style dates here; it is my understanding that such long's can also be negative to represent 
        dates long before 1970, or positive for dates long after 1970. <br>
        <br>
        In the case of inNumber, note
        that the postgresql docs give some warnings about the precision of its real and "double precision" types. Given those
        warnings and the fact that I haven't investigated carefully (as of 9/2002) how the data will be saved and read 
        between the java float type and the postgresql types, I am using "double precision" as the postgresql data type, 
        as a guess to try to lose as
        little information as possible, and I'm making this note to you the reader, so that if you care about the exactness
        of the data you can do some research and let us know what you find, at om-list@onemodel.org.
    */
    public long /*id*/ createQuantityAttribute(long inParentId, long inUnitId, float inNumber, long inAttrTypeId, Long inValidOnDate, long inObservationDate) throws Exception {
        long id = getNewKey("QuantityAttributeKeySequence");
        String sql = "insert into QuantityAttribute values (" + inParentId + "," + id + "," + inUnitId + "," + inNumber + "," + inAttrTypeId + "," + inValidOnDate + "," + inObservationDate + ")";
        createObject(sql);
        return id;        
    }
    
    public long /*id*/ createTextAttribute(long inParentId, String inText, long inAttrTypeId, Long inValidOnDate, long inObservationDate) throws Exception {
        long id = getNewKey("TextAttributeKeySequence");
        String sql = "insert into TextAttribute values (" + inParentId + "," + id + ",'" + inText + "'," + inAttrTypeId + "," + inValidOnDate + "," + inObservationDate + ")";
        createObject(sql);
        return id;        
    }
    
    public long /*id*/ createEntity(String inName) throws Exception {
        if (inName==null || inName.length()==0) {
            throw new Exception("Name must have a value.");
        }
        long id = getNewKey("EntityKeySequence");
        String sql = "INSERT INTO Entity VALUES ('"+inName+"',"+id+")";
        createObject(sql);
        return id;
    }
    
    public void deleteEntity(long inID) throws Exception {
        deleteObject("Entity",inID);
    }
    
    public void deleteQuantityAttribute(long inID) throws Exception {
        deleteObject("QuantityAttribute",inID);
    }
    
    public void deleteTextAttribute(long inID) throws Exception {
        deleteObject("TextAttribute",inID);
    }
    
    public long getEntityCount() throws Exception {
        return countRows("SELECT count(1) from Entity");
    }
    
    public long getQuantityAttributeCount(long inEntityId) throws Exception {
        return countRows("select count(1) from QuantityAttribute where parent_id="+inEntityId);
    }

    public long getTextAttributeCount(long inEntityId) throws Exception {
        return countRows("select count(1) from TextAttribute where parent_id="+inEntityId);
    }

    public java.util.ArrayList getQuantityAttributeData(long inQuantityId) throws Exception {
        Statement st=null;
        ResultSet rs=null;
        boolean loopedOnce=false;
        java.util.ArrayList retval = new java.util.ArrayList();
        try {
            st = mConn.createStatement();
            rs = st.executeQuery("select parent_id, unit_id, quantity_number, attr_type_id, valid_on_date, observation_date from QuantityAttribute where id="+inQuantityId);
            while(rs.next()) {
                if (loopedOnce) {
                    throw new Exception("More than one QuantityAttribute results from query on QuantityAttribute id "+inQuantityId+"??");
                }
                // todo: this would be more efficient if we return an array instead of creating/reading all these
                // temporary objects!--but then what do about the Float value?
                retval.add(new Long(rs.getLong(1)));
                retval.add(new Long(rs.getLong(2)));
                retval.add(new Float(rs.getFloat(3)));
                retval.add(new Long(rs.getLong(4)));
                retval.add(new Long(rs.getLong(5)));
                retval.add(new Long(rs.getLong(6)));
                loopedOnce=true;
            }
        } finally {
            if (rs!=null) rs.close();
            if (st!=null) st.close();
        }
        return retval;
    }

    public java.util.ArrayList getTextAttributeData(long inTextId) throws Exception {
        Statement st=null;
        ResultSet rs=null;
        boolean loopedOnce=false;
        java.util.ArrayList retval = new java.util.ArrayList();
        try {
            st = mConn.createStatement();
            rs = st.executeQuery("select parent_id, textValue, attr_type_id, valid_on_date, observation_date from TextAttribute where id="+inTextId);
            while(rs.next()) {
                if (loopedOnce) {
                    throw new Exception("More than one TextAttribute results from query on TextAttribute id "+inTextId+"??");
                }
                // todo: this would be more efficient if we return an array instead of creating/reading all these
                // temporary objects!--but then what do about the Float value?
                retval.add(new Long(rs.getLong(1)));
                retval.add(rs.getString(2));
                retval.add(new Long(rs.getLong(3)));
                retval.add(new Long(rs.getLong(4)));
                retval.add(new Long(rs.getLong(5)));
                loopedOnce=true;
            }
        } finally {
            if (rs!=null) rs.close();
            if (st!=null) st.close();
        }
        return retval;
    }

    public boolean quantityAttributeKeyExists(long inID) throws Exception {
        long rowCnt = countRows("SELECT count(1) from QuantityAttribute where id="+inID);
        boolean retval=false;
        if (rowCnt==1) {
            retval=true;
        } else if (rowCnt > 1) {
            throw new Exception("How can there be > 1 entries in QuantityAttribute table for a key? ("+rowCnt+" found for "+inID+").");
        }
        return retval;
    }
    
    public boolean textAttributeKeyExists(long inID) throws Exception {
        long rowCnt = countRows("SELECT count(1) from TextAttribute where id="+inID);
        boolean retval=false;
        if (rowCnt==1) {
            retval=true;
        } else if (rowCnt > 1) {
            throw new Exception("How can there be > 1 entries in TextAttribute table for a key? ("+rowCnt+" found for "+inID+").");
        }
        return retval;
    }
    
    public boolean entityKeyExists(long inID) throws Exception {
        long rowCnt = countRows("SELECT count(1) from Entity where id="+inID);
        boolean retval=false;
        if (rowCnt==1) {
            retval=true;
        } else if (rowCnt > 1) {
            throw new Exception("How can there be > 1 entries in Entity table for a key? ("+rowCnt+" found for "+inID+").");
        }
        return retval;
    }
    
    public int getEntityNameLength() {
        return 60; //Might be nice to figure out how to do this by querying the DB, then writing a test for it. 
    }
    
    /** Allows querying for a range of objects in the database; returns a java.util.Map with keys and names. 
        1st parm is index to start with (0-based), 2nd parm is # of obj's to return.
    */
    public java.util.TreeMap getEntities(long inStartingObjectIndex, int inMaxVals) throws Exception {
        java.util.TreeMap retval = new java.util.TreeMap();
        Statement st=null;
        ResultSet rs=null;
        String name = null;
        long seq = 0;
        try {
            st = mConn.createStatement();
            rs = st.executeQuery("SELECT id, name from Entity order by id limit "+inMaxVals+" offset "+inStartingObjectIndex);
            boolean gotIt=false;
            while(rs.next()) {
                retval.put(new Long(rs.getLong(1)), rs.getString(2));
                gotIt=true;
            }
            /* removed: there could be 0 rows when user 1st starts using system
            if (! gotIt) {
                throw new Exception("Failed to get any rows for inStartingObjectIndex "+inStartingObjectIndex+" and inMaxVals "+inMaxVals+"."); 
            }*/
        } finally {
            if (rs!=null)  rs.close();
            if (st!=null) st.close();
        }
        return retval;
    }

    public String getEntityName(long inID) throws Exception { 
        Statement st=null;
        ResultSet rs=null;
        String retval=null;
        try {
            st = mConn.createStatement();
            rs = st.executeQuery("SELECT name from Entity where id="+inID);
            boolean gotIt=false;
            while(rs.next()) {
                retval=rs.getString(1);
                gotIt=true;
                break;
            }
            if (! gotIt) {
                throw new Exception("Failed to get name for key '"+inID+"'!"); 
            }
        } finally {
            if (rs!=null)  rs.close();
            if (st!=null) st.close();
        }
        return retval;
    }
    
    public java.util.SortedMap getEntityAttributeIdsAndAttributeTypeIds(long inID, long inStartingObjectIndex, long inMaxVals) throws Exception { // impl in MO as a treemap 4 now so it's sorted
        Statement st=null;
        ResultSet rs=null;
        Statement st2=null;
        ResultSet rs2=null;
        long id=0;
        long attrTypeId=0;
        java.util.TreeMap retval = new java.util.TreeMap();
        try {
            st = mConn.createStatement();
            rs = st.executeQuery("SELECT id, attr_type_id from QuantityAttribute where parent_id="+inID+" order by id limit "+inMaxVals+" offset "+inStartingObjectIndex);
            while(rs.next()) {
                id=rs.getLong(1);
                attrTypeId=rs.getLong(2);
                retval.put("quantity-"+rs.getLong(1), new Long(attrTypeId));
                break;
            }
            st2 = mConn.createStatement();
            rs2 = st.executeQuery("SELECT id, attr_type_id from TextAttribute where parent_id="+inID+" order by id limit "+inMaxVals+" offset "+inStartingObjectIndex);
            while(rs2.next()) {
                id=rs2.getLong(1);
                attrTypeId=rs2.getLong(2);
                retval.put("text-"+rs2.getLong(1), new Long(attrTypeId));
                break;
            }
        } finally {
            if (rs!=null) rs.close();
            if (st!=null) st.close();
            if (rs2!=null) rs2.close();
            if (st2!=null) st2.close();
        }
        return retval;
    }
    
    public long getAttrCount(long inID) throws Exception {
        return countRows("SELECT count(1) from QuantityAttribute where parent_id="+inID);
    }

    /** Like jdbc's default, if you don't call begin/rollback/commit, it will commit after every stmt, using the defa behavior of jdbc; but if you call begin/rollback/commit, it will let you manage explicitly and will automatically turn autocommit on/off as needed to allow that. */
    public void beginTrans() throws java.sql.SQLException {
        mConn.setAutoCommit(false); // implicitly begins a transaction, according to jdbc documentation
    }    
    public void rollbackTrans() throws java.sql.SQLException {
        mConn.rollback();
        mConn.setAutoCommit(true); // so future work is auto- committed unless programmer explicitly opens another transaction
    }
    public void commitTrans() throws java.sql.SQLException {
        mConn.commit();
        mConn.setAutoCommit(true); // so future work is auto- committed unless programmer explicitly opens another transaction
    }
    
    public long getMaxIDValue() {
        // Max size for a Java long type, and for a postgresql 7.2.1 bigint type (which is being used, at the moment, for the id value in Entity table.
        return 9223372036854775807l; // (ends w/ 'l' (lowercase L) for long) 
    }
    
    protected void finalize() throws java.sql.SQLException {
        if (mConn!=null) { mConn.close(); }
    }
    
    private long countRows(String inSQL) throws Exception {
        Statement st=null;
        ResultSet rs=null;
        long retval=0;
        try {
            st = mConn.createStatement();
            rs = st.executeQuery(inSQL);
            boolean gotIt=false;
            while(rs.next()) {
                retval = rs.getLong(1);
                gotIt=true;
                break;
            }
            if (! gotIt) {
                throw new Exception("Failed to get row count!"); 
            }
        } finally {
            if (rs!=null)  rs.close();
            if (st!=null) st.close();
        }
        return retval;
    }
    
    private void createObject(String inSQL) throws Exception {
        Statement st2=null;
        int rowsInserted =0;
        try {            
            st2 = mConn.createStatement();
            rowsInserted = st2.executeUpdate(inSQL);
        } finally {
            if (st2!=null) st2.close();
        }
        if (rowsInserted!=1) {
            throw new Exception("Inserted "+rowsInserted+" rows instead of 1? SQL was: "+inSQL);
        }
    }
    
    private void deleteObject(String inTableName, long inID) throws Exception {
        Statement st=null;
        try {
            st = mConn.createStatement();
            String sql = "DELETE FROM "+inTableName+" where id="+inID;
            int rowsdeleted = st.executeUpdate(sql);
            if (rowsdeleted!=1) {
                throw new Exception("Deleted "+rowsdeleted+" when it should have deleted 1! SQL was: "+sql);
            }
        } finally {
            if (st!=null) st.close();
        }
    }
    
    /** although the next sequence value would be set automatically as the default for a column (at least the
        way I have them defined so far in postgresql); we do it explicitly by retrie
        so we know what sequence value to return, and what the unique key is of the row we just created!
    */
    private long /*id*/ getNewKey(String inSequenceName) throws Exception {
        Statement st=null;
        ResultSet rs=null;
        long id=0;
        try {
            st = mConn.createStatement();
            rs = st.executeQuery("SELECT nextval('"+inSequenceName+"')");
            boolean gotIt=false;
            while(rs.next()) {
                id=rs.getLong(1);
                gotIt=true;
                break;
            }
            if (! gotIt) {
                throw new Exception("Failed to get new id (sequence) number; cannot insert row."); 
            }
        } finally {
            if (rs!=null) rs.close();
            if (st!=null) st.close();
        }
        return id;
    }
    
    private Connection mConn;
 }
