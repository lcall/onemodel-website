/*
    Copyright (c) 2002-2003, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

import junit.framework.*;
import java.sql.*;
//import org.netbeans.junit.*;

/**
    PostgreSQLDatabaseTest.java: 
    JUnit based test code.
*/
public class PostgreSQLDatabaseTest extends TestCase {
    
    public PostgreSQLDatabaseTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) throws Exception {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(PostgreSQLDatabaseTest.class);
        
        return suite;
    }
    
    protected void setUp() throws Exception {
        // connect to existing database first
        mDB = new PostgreSQLDatabase();
        setupTestDBAndConnect(mDB);
    }
    
    protected void tearDown() throws Exception {
        tearDownTestDB(mDB);
    }
    
    /** This one has access permission allowing it to be called from other classes in this package, like EntityTest.
    */
    static void setupTestDBAndConnect(Database inDB) throws java.sql.SQLException {
        // create the database we want and reconnect to it
        //  first make sure it's not already there; if so drop it to clean out old data:
        try {
            inDB.destroyDatabase("testmodel");
        } catch (java.sql.SQLException e) {
            if (e.toString().indexOf("does not exist")!=-1) {
                // This is normal; nothing to clean up or worry about.
            } else {
                throw e;
            }
        }
        inDB.createDatabase("testmodel");
        inDB.connect("testmodel");
        inDB.createTables();
        
        //inDB.destroyDatabase("testmodel");//%%TEST/DEBUGGING: REMOVE!
    }
    
    /** Has access permissions allowing to be called from other classes like EntityTest.
    */
    static void tearDownTestDB(Database inDB) throws java.sql.SQLException {
        // reconnect to the normal production database and tear down the temporary one we used for testing.
        inDB.connect("FirstModel"); //  (PostgreSQLDatabase finalizer will disconnect automatically)            
        try {
            inDB.destroyDatabase("testmodel");
        } catch (java.sql.SQLException e) {
            if (e.toString().indexOf("database \"testmodel\" is being accessed by other users")!=-1) {
                //todo: why does this happen sometimes?
                // ignore--we'll clean up when starting tests, next time through.
            } else {
                throw e;
            }
        }
    }
        
    /** Test of createEntity method, of class org.onemodel.Database. */
    public void testManyDBMethods() throws Exception {
        System.out.println("testManyDatabaseMethds");
        String name="test: org.onemodel.PostgreSQLDatabaseTest.testManyDBMethds()";
        if (name.length() > mDB.getEntityNameLength()) {
            name = name.substring(0,mDB.getEntityNameLength());
            fail("cannot use name longer than the object name length; will truncate for remaining tests");
        }
        
        // create an object & make sure the object count goes up by one, and that the object is there as expected
        // also test transactions
        mDB.beginTrans();
        long firstCount=mDB.getEntityCount();
        long id = mDB.createEntity(name);
        long newCount=mDB.getEntityCount();
        if (firstCount+1 != newCount) {
            fail("getEntityCount after adding doesn't match prior count+1! Before: "+firstCount+", after: "+newCount+".");
        }
        boolean exists = mDB.entityKeyExists(id);
        if (! exists) {
            fail("entityKeyExists after adding object returned false.");
        }
        mDB.rollbackTrans();
        
        // now should not exist
        newCount=mDB.getEntityCount();
        if (firstCount != newCount) {
            fail("getEntityCount after rollback should match prior count! Before: "+firstCount+", after: "+newCount+".");
        }
        exists = mDB.entityKeyExists(id);
        if (exists) {
            fail("entityKeyExists after rollback returned true.");
        }
        
        // now create it again
        mDB.beginTrans();
        firstCount=mDB.getEntityCount();
        id = mDB.createEntity(name);
        
        //This section tests QuantityAttribute and many aspects of the database to make sure we have it set up right, etc.
        //and create a quantity attribute, assigned to it
        long quantityAttributeId = createTestQuantityAttributeWithTwoEntities(id);
        long quantityAttributeCount = mDB.getQuantityAttributeCount(id);
        if (quantityAttributeCount == 0) {
            fail("Creating the QuantityAttribute object reported 0 count?");
        }
        //delete the quantity attribute: #'s still right?
        long moCountBeforeQuantityDeletion = mDB.getEntityCount();
        mDB.deleteQuantityAttribute(quantityAttributeId);
        quantityAttributeCount = mDB.getQuantityAttributeCount(id);
        long moCountAfterQuantityDeletion = mDB.getEntityCount();
        if (quantityAttributeCount > 0) {
            fail("Deleting QuantityAttribute object reported > 0 count?");
        }
        if (moCountAfterQuantityDeletion!=moCountBeforeQuantityDeletion) {
            fail("Got constraint backwards? Deleting quantity attribute changed Entity count from "+moCountBeforeQuantityDeletion+" to "+moCountAfterQuantityDeletion);
        }
        // then recreate the quantity attribute (to verify its auto-deletion when Entity is deleted, below)
        quantityAttributeId = createTestQuantityAttributeWithTwoEntities(id);
        
        
        // now also test TextAttribute stuff: 
        long textAttributeId = createTestTextAttributeWithOneEntity(id);
        long textAttributeCount = mDB.getTextAttributeCount(id);
        if (textAttributeCount == 0) {
            fail("Creating the text attribute object reported 0 count?");
        }
        //delete the text attribute: #'s still right?
        long moCountBeforeTextDeletion = mDB.getEntityCount();
        mDB.deleteTextAttribute(textAttributeId);
        textAttributeCount = mDB.getTextAttributeCount(id);
        long moCountAfterTextDeletion = mDB.getEntityCount();
        if (textAttributeCount > 0) {
            fail("Deleting text attribute object reported > 0 count?");
        }
        if (moCountAfterTextDeletion!=moCountBeforeTextDeletion) {
            fail("Got constraint backwards? Deleting text attribute changed Entity count from "+moCountBeforeTextDeletion+" to "+moCountAfterTextDeletion);
        }
        // then recreate the text attribute (to verify its auto-deletion when Entity is deleted, below)
        textAttributeId = createTestTextAttributeWithOneEntity(id);
        
        
        // test that we can retrieve both of them properly
        verifyTestQuantityAndTextAttributeCreation(id);
        
        
        if (! name.equals(mDB.getEntityName(id))) {
            fail("created object's name does not match name given.");
        }
        java.util.TreeMap objects = mDB.getEntities(0, 1); // todo: need a better (more thorough) test for getEntities() than this.
        java.util.Iterator i = objects.keySet().iterator();
        boolean found=false;
        while (i.hasNext()) {
            if (id != ((Long)(i.next())).longValue()) {
                fail("getEntities returned id that does not match the one created in the testManyDatabaseMethods().");
            }
            found=true;
            break;    
        }
        if (! found) {
            fail("getEntities() after adding object returned nothing.");
        }
        
        // now clean up & make sure that looks right also.    
        mDB.deleteEntity(id);
        newCount=mDB.getEntityCount();
        if (firstCount + 6 != newCount) { // + 4 because each "createTestQuantityAttributeWithTwoEntities()" (we have two) adds two (temporarily) and each "createTestTextAttributeWithOneEntity()" creates one (we also have two).
            fail("getEntityCount after add/delete doesn't match original count! Original: "+firstCount+", after add/del: "+newCount+".");
        }
        exists = mDB.entityKeyExists(id);
        if (exists) {
            fail("entityKeyExists after deleting object returned true.");
        }
        // also make sure that deleting the Entity automatically deleted its quantity attribute
        quantityAttributeCount = mDB.getQuantityAttributeCount(id);
        if (quantityAttributeCount > 0) {
            fail("Deleting the model object should also have deleted the quantity object.");
        }
        
        mDB.commitTrans();
    }
    
    public void testAddQuantityAttributeWithBadParentID() throws Exception {
        int x=0;//test of nothing, temp.
        long badParentId = findIdWhichIsNotKeyOfAnyEntity();
        boolean gotException=false;
        
        try {
            createTestQuantityAttributeWithTwoEntities(badParentId);
        } catch (Exception e) {
            gotException=true; // desired here
            // replace for the benefit of the tester in case something does not work as expected?
            //e.printStackTrace();
        }
        
        if (! gotException) {
            fail("Database should not allow adding quantity with a bad parent (Entity) ID!");
        }
    }
    
    private long createTestQuantityAttributeWithTwoEntities(long inParentId) throws Exception {
        long unitId = mDB.createEntity("centimeters");
        long attrTypeId = mDB.createEntity(QUANTITY_TYPE_NAME);
        long defaultDate = System.currentTimeMillis();
        Long validOnDate = new Long(defaultDate);
        long observationDate = defaultDate;
        float number=50; 
        long quantityId = mDB.createQuantityAttribute(inParentId,unitId, number, attrTypeId, validOnDate, observationDate);
        
        // and verify it:
        java.util.ArrayList quantityData = mDB.getQuantityAttributeData(quantityId);
        long checkParentId = ((Long)quantityData.get(0)).longValue();
        if (inParentId != checkParentId) {
            fail("parent id not returned properly from quantity attribute? was:"+checkParentId+", should be "+inParentId+".");
        }
        long checkUnitId=((Long)quantityData.get(1)).longValue();
        if (checkUnitId != unitId) {
            fail("UnitId not returned properly from quantity attribute? was:"+checkUnitId+", should be "+unitId+".");
        }
        float checkNumber =((Float)quantityData.get(2)).floatValue();
        if (checkNumber != number) {
            fail("Number not returned properly from quantity attribute? was:"+checkNumber+", should be "+number+".");
        }
        long checkAttrTypeId=((Long)quantityData.get(3)).longValue();
        if (checkAttrTypeId != attrTypeId) {
            fail("AttrTypeId not returned properly from quantity attribute? was:"+checkAttrTypeId+", should be "+attrTypeId+".");
        }
        long checkValidOnDate=((Long)quantityData.get(4)).longValue();
        if (checkValidOnDate != validOnDate.longValue()) {
            fail("ValidOnDate not returned properly from quantity attribute? was:"+checkValidOnDate+", should be "+validOnDate+".");
        }
        long checkObservationDate=((Long)quantityData.get(5)).longValue();
        if (checkObservationDate != observationDate) {
            fail("ObservationDate not returned properly from quantity attribute? was:"+checkObservationDate+", should be "+observationDate+".");
        }
        
        return quantityId;
    }
    private void verifyTestQuantityAndTextAttributeCreation(long inEntityId) throws Exception {
        // (the 3rd parameter below is arbitrary; could be one (1). )
        java.util.SortedMap attrs = mDB.getEntityAttributeIdsAndAttributeTypeIds(inEntityId,0,15); // impl in MO as a treemap 4 now so it's sorted
        java.util.Iterator keys = attrs.keySet().iterator();
        int counter = 0;
        int typesFoundCount = 0;
        String typeName="";
        String typeNames="";
        while (keys.hasNext()) {
            //Object key = keys.next();
            counter++;
            String key = (String)(keys.next());
            
            //unused but here's the info:
            //int hyphenLocation = key.indexOf("-");
            //String attrType=key.substring(0,hyphenLocation);
            //String attrId = key.substring(hyphenLocation+1);
            
            //long typeId=Long.parseLong(attrId);
            long typeId = ((Long)(attrs.get(key))).longValue();
            typeName = mDB.getEntityName(typeId);
            if (typeName.equals(QUANTITY_TYPE_NAME)) {//since that's what we added above
                typesFoundCount++;
            }
            if (typeName.equals(TEXT_TYPE_NAME)) {//since that's what we added above
                typesFoundCount++;
            }
            typeName += ", ";
            typeNames += typeName;
        }
        if (typesFoundCount!=2){
            fail("Added a \""+QUANTITY_TYPE_NAME+"\" quantity and a \""+TEXT_TYPE_NAME+"\" text attribute, but typeNames returned "+typeNames+", and typesFoundCount = "+typesFoundCount+"?");
        }
        if (counter!=2) { // we added one quantity and one text attribute above, so it should
            fail("We added two attrs (quantity & text), but getAttributeIdsAndAttributeTypeIds() returned "+counter+"?");
        }
    }
    private long createTestTextAttributeWithOneEntity(long inParentId) throws Exception {
        long attrTypeId = mDB.createEntity(TEXT_TYPE_NAME);
        long defaultDate = System.currentTimeMillis();
        Long validOnDate = new Long(defaultDate);
        long observationDate = defaultDate;
        String text = "some test text";
        long textAttributeId = mDB.createTextAttribute(inParentId, text, attrTypeId, validOnDate, observationDate);
        
        // and verify it:
        java.util.ArrayList textAttributeData = mDB.getTextAttributeData(textAttributeId);
        long checkParentId = ((Long)textAttributeData.get(0)).longValue();
        if (inParentId != checkParentId) {
            fail("parent id not returned properly from text attribute? was:"+checkParentId+", should be "+inParentId+".");
        }
        String checkText = (String)(textAttributeData.get(1));
        if (! checkText.equals(text)) {
            fail("Text not returned properly from text attribute? was:"+checkText+", should be "+text+".");
        }
        long checkAttrTypeId=((Long)textAttributeData.get(2)).longValue();
        if (checkAttrTypeId != attrTypeId) {
            fail("AttrTypeId not returned properly from text attribute? was:"+checkAttrTypeId+", should be "+attrTypeId+".");
        }
        long checkValidOnDate=((Long)textAttributeData.get(3)).longValue();
        if (checkValidOnDate != validOnDate.longValue()) {
            fail("ValidOnDate not returned properly from text attribute? was:"+checkValidOnDate+", should be "+validOnDate+".");
        }
        long checkObservationDate=((Long)textAttributeData.get(4)).longValue();
        if (checkObservationDate != observationDate) {
            fail("ObservationDate not returned properly from text attribute? was:"+checkObservationDate+", should be "+observationDate+".");
        }
        
        return textAttributeId;
    }
    /*not needed, if combined w/ verifyTestQuantityAndTextAttr...() above, right?
    private void verifyTestTextAttributeCreation(long inEntityId) throws Exception {
        // (the 3rd parameter below is arbitrary; could be one (1). )
        java.util.SortedMap attrs = mDB.getEntityAttributeIdsAndAttributeTypeIds(inEntityId,0,15); // impl in MO as a treemap 4 now so it's sorted
        java.util.Iterator keys = attrs.keySet().iterator();
        int counter = 0;
        String typeName="";
        while (keys.hasNext()) {
            Object key = keys.next();
            counter++;
            long typeId=((Long)(attrs.get(key))).longValue();
            typeName = mDB.getEntityName(typeId);
        }
        if (counter!=1) { // we added one text attribute above, so it should
            fail("We added one quantity, but getAttributeIdsAndAttributeTypeIds() returned "+counter+"?");
        }
        if (!typeName.equals(QUANTITY_TYPE_NAME)) {//since that's what we added above
            fail("Added a \"length\" quantity, but typeName returned "+typeName+"?");
        }
    }*/
        
    
    private long findIdWhichIsNotKeyOfAnyEntity() throws Exception {
        long startingId=0;
        long workingId = startingId;
        while (true) {
            if (mDB.entityKeyExists(workingId)) {
                workingId++;
                if (workingId==startingId) {
                    throw new Exception("No id found which is not a key of any model object. How could all id's be used??");
                }
                continue;
            } else {
                return workingId;
            }
        }
    }
    
    // Add test methods here, they have to start with 'test...' name.
    // for example:
    // public void testHello() {}
    
    Database mDB;
    
    private static final String TEXT_TYPE_NAME = "someTextTypeLikeName";
    private static final String QUANTITY_TYPE_NAME = "length";
}
