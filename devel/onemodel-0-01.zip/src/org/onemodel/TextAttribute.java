/*
    Copyright (c) 2002-2003, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

/** Represents one String object in the system (usually [always, as of 9/2002] used as an attribute on a Entity). 
 */
public class TextAttribute {
    
    /** This constructor instantiates an existing object from the DB. You can use Entity.addTextAttribute() to 
        create a new object. 
    */
    TextAttribute(long inId, Database inDB) throws Exception {
        if (inDB.textAttributeKeyExists(inId)) {
            mDB = inDB;
            mId = inId;
        } else {
            throw new Exception("Key "+inId+" does not exist in database."); // DON'T CHANGE this msg unless you also change the trap for it, if used, in other code.
        }
    }
    
    /** return some string 
    */
    static String getDisplayString(long inStringId, Model inModel, Database inDB) throws Exception {
        TextAttribute t = new TextAttribute(inStringId,inDB);
        String typeName = inModel.getObjectName(t.getAttrTypeId());
        String text = t.getText();
        if (text.length()>503) {
            text = text.substring(0,503)+"...";
        }
        return typeName + ": " + text;
    }
    
    String getText() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mText;
    }
    long getId() { return mId; } 
    long getParentId() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mParentId;
    }
    long getAttrTypeId() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mAttrTypeId;
    }
    long getValidOnDate() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mValidOnDate;
    }
    long getObservationDate() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mObservationDate;
    }
    
    private void readDataFromDB() throws Exception {
        java.util.ArrayList textAttrData = mDB.getTextAttributeData(mId);
        
        mParentId=((Long)textAttrData.get(0)).longValue();
        mText = (String)textAttrData.get(1);
        mAttrTypeId=((Long)textAttrData.get(2)).longValue();
        mValidOnDate=((Long)textAttrData.get(3)).longValue();
        mObservationDate=((Long)textAttrData.get(4)).longValue();
        
        mAlreadyReadData=true;
    }

    
    /** Removes this object from the system. */
    void delete() throws Exception {
        mDB.deleteTextAttribute(mId);
    }
    
    private Database mDB;
    private boolean mAlreadyReadData=false;
    
    /** For descriptions of the meanings of these variables, see the comments 
        on PostgreSQLDatabase.createTextAttribute(...).
    */
    private long mParentId;
    private long mId; // the unique identifier assigned to this object in the database.
    private String mText;
    private long mAttrTypeId;
    private long mValidOnDate;
    private long mObservationDate;
}
