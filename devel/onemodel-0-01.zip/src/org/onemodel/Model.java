/*
    Copyright (c) 2002-2003, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

/** This is the primary mechanism through which user interfaces or other applications
    gain access to data in the system: it is the "Model" in a model/view/controller-like 
    system. It may seem like a small, useless layer over the Database class, but it is 
    the place for any logic which is specific to the (data) "model" but which would not 
    change when we change databases (i.e., from postgresql to some other back end.).
 *
 * @author  lacall
 */
public class Model {
    Model() throws Exception {
        // could use conditional logic here to decide which database type to load!
        mDB = (Database)((Class.forName("org.onemodel.PostgreSQLDatabase")).newInstance());
    }
    
    Entity createObject(String inName) throws Exception {
        long id = mDB.createEntity(inName.trim());
        Entity mo = new Entity(id, mDB);
        return mo;
    }
    
    String getQuantityDisplayString(long inQuantityAttributeId) throws Exception {
        return QuantityAttribute.getDisplayString(inQuantityAttributeId, this, mDB);
    }
    
    String getTextDisplayString(long inTextAttributeId) throws Exception {
        return TextAttribute.getDisplayString(inTextAttributeId, this, mDB);
    }
    
    Entity getObject(long inKey) throws Exception {
        return new Entity(inKey, mDB);
    }
    
    /** Allows querying for a range of objects in the database; returns a java.util.Map with keys and names. 
        1st parm is index to start with (0-based), 2nd parm is # of obj's to return.
    */
    java.util.Map getEntities(long inStartingObjectIndex, int inMaxVals) throws Exception {
        return mDB.getEntities(inStartingObjectIndex, inMaxVals);
    }
    
    long getObjectCount() throws Exception {
        return mDB.getEntityCount();
    }
    
    long getMaxIDValue() {
        return mDB.getMaxIDValue();
    }
    
    int getObjectNameLength() {
        return mDB.getEntityNameLength();
    }
    
    /** Only use if you don't have or currently want an instance of the object. If you have an
        instance, call "instance.getName()" instead?
    */
    String getObjectName(long inKey) throws Exception {
        return mDB.getEntityName(inKey);
    }
    
    Database mDB;
}
