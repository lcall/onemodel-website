/*
    Copyright (c) 2002-2003, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

import java.util.Date;

/** Represents one object in the system.
 */
public class Entity {
    
    /** This constructor instantiates an existing object from the DB. Generally use Model.createObject() to create a new object. */
    Entity(long inID, Database inDB) throws Exception {
        if (inDB.entityKeyExists(inID)) {
            mDB = inDB;
            mID = inID;
        } else {
            throw new Exception("Key "+inID+" does not exist in database."); // DON'T CHANGE this msg unless you also change the trap for it in TextUI.java.
        }
    }
    
    String getName() throws Exception {
        //maybe: see if name has been read (vars below); if so return it, if not query DB for it?
        if (! mAlreadyReadName) {
            mName=mDB.getEntityName(mID);
            mAlreadyReadName=true;
        }
        return mName;
    }
    
    long getID() { return mID; } 
    
    java.util.SortedMap getAttributeIdsAndAttributeTypeIds(long inStartingObjectIndex, int inMaxVals) throws Exception { 
        return mDB.getEntityAttributeIdsAndAttributeTypeIds(mID, inStartingObjectIndex, inMaxVals);
    }
    
    long getAttrCount() throws Exception {
        return mDB.getAttrCount(mID);
    }
    
    /** Removes this object from the system. */
    void delete() throws Exception {
        mDB.deleteEntity(mID);
    }
    
    /** Creates a quantity attribute on this Entity, with default values of "now" for the dates. See Database.addQuantityAttribute(...)
        for explanation of the parameters. It might also be nice to add the recorder's ID (person or app), but we'd have to do some kind 
        of authentication/login 1st?
    */
    long /*id*/ addQuantityAttribute(long inUnitId, float inNumber, long inAttrTypeId) throws Exception {
        long defaultDate = System.currentTimeMillis();
        long validOnDate = defaultDate; // usually matches date observed; null means asserted true for all time(?)
        long observationDate = defaultDate; //map java long to postgresql bigint, for dates.
        return mDB.createQuantityAttribute(mID, inUnitId, inNumber, inAttrTypeId, new Long(validOnDate), observationDate);
    }
    
    /** For convenience--see other similarly named methods for details.
    */
    long /*id*/ addQuantityAttribute(Entity inUnit, float inNumber, Entity inAttrType) throws Exception  {
        return addQuantityAttribute(inUnit.getID(), inNumber, inAttrType.getID());
    }
    
    /** Creates a quantity attribute for this Entity (i.e., "6 inches length"). See Database.createQuantityAttribute(...) for details. 
    */
    long /*id*/ addQuantityAttribute(long inUnitId, float inNumber, long inAttrTypeId, Date inValidOnDate, Date inObservationDate) throws Exception {
        if (inObservationDate==null) {
            throw new Exception("inObservationDate should not be null");
        }
        // write it to the database table--w/ a record for all these attributes plus a key indicating which Entity
        // it all goes with
        return mDB.createQuantityAttribute(mID,inUnitId, inNumber, inAttrTypeId, new Long(inValidOnDate.getTime()), inObservationDate.getTime());
    }
    
    /** For convenience--see other similarly named methods for details.
    */
    long /*id*/ addQuantityAttribute(Entity inUnit, float inNumber, Entity inAttrType, Date inValidOnDate, Date inObservationDate) throws Exception {
        return addQuantityAttribute(inUnit.getID(), inNumber, inAttrType.getID(), inValidOnDate, inObservationDate);
    }
    
    QuantityAttribute /*qo*/ getQuantityAttribute(long inKey) throws Exception {
        return new QuantityAttribute(inKey, mDB);
    }
    
    TextAttribute /*qo*/ getTextAttribute(long inKey) throws Exception {
        return new TextAttribute(inKey, mDB);
    }
    
    /** See addQuantityAttribute(...) methods for comments. */
    long /*id*/ addTextAttribute(String inText, long inAttrTypeId) throws Exception {
        long defaultDate = System.currentTimeMillis();
        long validOnDate = defaultDate; // usually matches date observed; null means asserted true for all time(?)
        long observationDate = defaultDate; //map java long to postgresql bigint, for dates.
        return addTextAttribute(inText, inAttrTypeId, new Date(validOnDate), new Date(observationDate)); 
    }
    
    long /*id*/ addTextAttribute(String inText, long inAttrTypeId, Date inValidOnDate, Date inObservationDate) throws Exception {
        return mDB.createTextAttribute(mID, inText, inAttrTypeId, new Long(inValidOnDate.getTime()), inObservationDate.getTime());
    }
    
    private long mID; // the unique ID assigned to this object in the database.
    private Database mDB;
    private boolean mAlreadyReadName=false;
    private String mName;
}
