/*
    Copyright (c) 2002-2003, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

import junit.framework.*;
import java.util.Date;

/** uses junit. */
public class EntityTest extends TestCase {
    
    public EntityTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(EntityTest.class);
        
        return suite;
    }
    
    protected void setUp() throws Exception {
        //if (mEntity==null) {
        //if (! mDidSetup) {
        //todo: find better way to make us create the database once for all the tests, tear down once?
            mDB = new PostgreSQLDatabase();
            PostgreSQLDatabaseTest.setupTestDBAndConnect(mDB);
            mUnitId = mDB.createEntity("centimeters");
            mQuantityAttrTypeId = mDB.createEntity("length"); // don't change unless also change the check inside testAddQuantityAttribute().
            mTextAttrTypeId = mDB.createEntity("someName"); // similarly, don't change unless....
            long id = mDB.createEntity("test object");
            mEntity = new Entity(id, mDB);
            //mDidSetup=true;
        /*} else {
            mDidSetup=false;
        }*/
    }
    
    protected void tearDown() throws Exception {
        //if (mDidSetup) {
            PostgreSQLDatabaseTest.tearDownTestDB(mDB);
            //mEntity=null;
            //mDidSetup=false;
        //}
    }
    
    public void testAddQuantityAttribute() throws Exception {
        System.out.println("testAddQuantityAttribute");
        //related methods:
        //mo.addQuantityAttribute(long inUnitId, float inNumber, long inAttrType, Date inValidOnDate, Date inObservationDate); 
        //mDB.createQuantityAttribute(mID,inUnitId, inNumber, inAttrTypeId, inValidOnDate.getTime(), inObservationDate.getTime());
        //long /*id*/ mo.addQuantityAttribute(long inUnitId, float inNumber, long inAttrType)
        
        long id = mEntity.addQuantityAttribute(mUnitId, 100, mQuantityAttrTypeId);
        QuantityAttribute qo = mEntity.getQuantityAttribute(id);
        if (qo == null) {
            fail("addQuantityAttribute then getQuantityAttribute returned null");
        }
    }
    
    
    public void testAddTextAttribute() throws Exception {
        System.out.println("testAddTextAttribute");
        long id = mEntity.addTextAttribute("This is someName given to an object", mTextAttrTypeId);
        TextAttribute t = mEntity.getTextAttribute(id);
        if (t == null) {
            fail("addTextAttribute then getTextAttribute returned null");
        }
    }
    
    /** Test of getName method, of class org.onemodel.Entity. */
   /* public void testGetName() {
        System.out.println("testGetName");
        
        // Add your test code below by replacing the default call to fail.
        fail("The test case is empty.");
    }
    
    public void testDestroy() {
        fail("test is mt");
    }
    */
    // Add test methods here, they have to start with 'test' name.
    // for example:
    // public void testHello() {}
    
    private static Entity mEntity;
    private static long mUnitId;
    private static Database mDB;
    private static long mQuantityAttrTypeId;
    private static long mTextAttrTypeId;
    //private static boolean mDidSetup=false;
}
