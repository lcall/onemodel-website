/*
    Copyright (c) 2002-2003, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

import java.io.*;
import java.util.*;

/** Provides a simple text-based interface for people who like that, or for use over a telnet or ssh connection. 
    The first OM user interface, it is intended to demonstrate basic concepts until we can make something more friendly. 
 */
public class TextUI {    
    public static void main(String[] args) throws Exception {
        showCopyright();
        
        TextUI tui = new TextUI();
        tui.launchUI();
    }
    
    TextUI() throws Exception {
        mModel = new Model();
        
        // get default object ID from user preferences; try to use it:
        mPrefs = java.util.prefs.Preferences.userNodeForPackage(this.getClass());
        // Max id used as default here because it seems the least likely # to be used in the system hence the 
        // most likely to cause an error as default by being missing, so the system can respond by prompting 
        // the user in some other way for a use.
        mFirstDisplayObject = mPrefs.getLong("first_display_object", mModel.getMaxIDValue());
        try {
            mEntity = mModel.getObject(mFirstDisplayObject); // returns null if nothing found at index mFirstDisplayObject
        } catch (Exception e) {
            if (e.toString().indexOf("does not exist in database.")!=-1) {
                mEntity = null; // this will let user create/set default later.
            } else {
                throw e;
            }
        }
    }                                                                           
    
    public void launchUI() throws Exception {
        if (mEntity!=null) {
            // default data exists, so display that first
            displayObjAttributesWithMenu();
            /*
             How?
                -now, in it, fill in choices and new methods I named, to make it have the ability to
                select an attribute (for editing/deleting), add attributes, etc.
                    %% (get it so I can release it to the group. (& express concerns re worth at this point?) )
                
                finish?: user story here is:
                    xUI launches, shows defa obj & its attrs, w/ (existing) main menu
                        (change that displayattrsw/attrmenu to just dispAttrs again?)
                    xUser selects add attribute
                    Gets below menu & works w/ it
                    object menu: add attribute: resulting menu: 
                        1- quantity (a numeric value like "length")
                        2- string (example: a serial number)
                            [%%and a test to impl this!]
                        3- reference (example: the attribute is a relationship which 
                            refers to another object like "mother" or "spouse" or "container"
                            [but, should this be differently handled, based on my notes on 
                            relationships between objects? ck on it.]
                            [%%and a test to impl this!]
                        4- help 
                            -> more definitions/examples of the above, such as
                                -the reference'd object should already have been created
                                -Number (w/ or w/o decimal; like a quantity) or string (mixture of 
                                 #'s & letters--not a quantity
                                -ssn has #'s but is not a quantity.)
                            0-back to main menu
                    Also on object menu sometime: a way to select, delete/edit attribute (as object--sel 1st as obj?)
                    
                    Does what to let you (which)?: delete/edit it, treat it as a separate object, whatever (so 
                    you can navigate easily among related objects. (Do the above & below notes 1st, then see
                    from using it what makes the most sense--maybe selecting is simple, and simply handles both?).
                
                Note: when I add the display & other code for other kinds of attributes, I can display them by
                including, along with the map of Quantity attrs, the other attrs in the map, and creating an array
                alongside the map that says which type of attr I have, so that the menu keystroke handler can
                decide which type of object to pull out & work with, but the display code can do its thing regardless-??
                    perhaps do this by calling additional objects' methods (besides quantity) 
                    in: mEntity.getAttributeIdsAndAttributeTypeIds().
                
                -When done w/ the above, should I (for efficiency) get rid of getAttributeIdsAndAttributeTypeIds() 
                 in
                 favor of just a "getAttributeIds()", then query for the attrtypes by calling QUantity methods? (since 
                 that may be cheaper/simpler?) But, i need somethingi n the map to pass to the displayObjAttributesWithMenu
                 method here?
            */
        } else {
            System.out.println("Default object at not found. You may want to find or create an object and set it as your default." );
        }
        
        System.out.println();
        
        // show menu and handle user input:
        while (true) {
            displayMainMenu();
            
            int input = getUserInputInt();
            
            handleMainMenuInput(input);
        }
    }
    
    private void displayMainMenu() throws Exception {
        if (mEntity!=null) {
            System.out.println();
            System.out.println("**CURRENT SELECTION: "+mEntity.getName());
        }
        System.out.println("OM menu:");
        System.out.println("1-Create new item");
        System.out.println("2-List objects");
        if (mEntity!=null) {
            System.out.println("3-Delete current object");
            System.out.println("4-Attributes for current object");
            System.out.println("5-Set as default (sets this obj as first to come up when launching application.)");
        }
        System.out.println("0-Quit");
        System.out.println();
    }        
    
    private void handleMainMenuInput(int input) throws Exception {
        if (input=='1') {
            promptForNameAndCreateObject();
        } else if (input=='2') {
            Long selection = displayObjectListMenuAndSelectObject(null);
            if (selection!=null) {
                long selectedId = selection.longValue();
                mEntity = mModel.getObject(selectedId);
            }
        } else if ((input=='3')  &&  mEntity!=null) {
            System.out.println("Delete object: are you sure?");
            input = getUserInputInt();
            if (input=='y' || input=='Y') {
                mEntity.delete();
                
                Long selection = displayObjectListMenuAndSelectObject(null);
                if (selection!=null) {
                    long selectedId = selection.longValue();
                    mEntity = mModel.getObject(selectedId);
                }
            }
        } else if ((input=='4')  &&  mEntity!=null) {
            displayObjAttributesWithMenu();
        } else if ((input=='5')  &&  mEntity!=null) {
            mPrefs.putLong("first_display_object",mEntity.getID()); // updates user preferences such that this obj will be the one displayed by default in future.
        } else if (input==48) { // numeral 0; was 27 for ESC
            System.exit(0);
        /*} else if (input==10 || input==13) { // it picked up the Enter key
            // do nothing.
            skipNextDisplay=true;*/
        } else {
            System.out.println("unknown command: "+input);
        }
    }
    
    private void promptForNameAndCreateObject() throws Exception {
        int nameLength = mModel.getObjectNameLength();
        byte[] name = new byte[nameLength];
        System.out.print("Enter object name (up to "+nameLength+" characters: ");
        int bytesRead = System.in.read(name);
        String nameStr = (new String(name,0,bytesRead)).trim(); // this trim is both in the TextUI class and in the Database class: in the TextUI class because it makes sense to have a client only pass good data, in the Database class because it makes sense to check things at the lowest level possible. The latter may have to be removed someday, if we decide we need to allow spaces as part of a name...?
        mEntity = mModel.createObject(nameStr);
        System.out.println("Created: "+nameStr);
        System.out.println();
        displayObjAttributesWithMenu();
    }
    
    private void displayObjAttributesWithMenu() throws Exception {
        /*modifying from other method: objects -> attrs
                    keys -> attrKeys
                    i -> keys
        */
        System.out.println("**CURRENT SELECTION: "+mEntity.getName());
        
        long numAttrsInObject = mEntity.getAttrCount(); // might be a little silly to do it this way, once it gets very big??
        long startingIndex = 0;
        String[] attrTypes = new String[mMaxLinesPerSceen];
        long[] attrKeys = new long[mMaxLinesPerSceen];
        //boolean attrSelected=false;
        
        BufferedReader inputStream = new BufferedReader(new InputStreamReader(System.in));
        
        while (true) {
            byte cnt=0;
            java.util.SortedMap attrs = mEntity.getAttributeIdsAndAttributeTypeIds(startingIndex, mMaxLinesPerSceen); // impl in MO as a treemap 4 now so it's sorted
            java.util.Iterator keys = attrs.keySet().iterator();
            while (keys.hasNext()) {
                String key = (String)(keys.next());
                int hyphenLocation = key.indexOf("-");
                attrTypes[cnt] = key.substring(0,hyphenLocation);
                attrKeys[cnt] = Long.parseLong(key.substring(hyphenLocation+1));
                cnt++;
                //long typeId=((Long)(attrs.get(key))).longValue();
                //String typeName = mModel.getObjectName(typeId);
                //System.out.println(key+": "+attrs.get(key));
                // //attrKeys[cnt++] = typeId;
            }
            
            /*if (!displayObjectGroup(mMaxLinesPerSceen, numAttrsInObject, startingIndex, attrs, attrKeys,"attrs",null)) {
                break;
            }*/
            displayObjectGroup(mMaxLinesPerSceen, numAttrsInObject, startingIndex, attrs, attrTypes, attrKeys,"attrs",null);
            
            showAttrListMenu();
            
            int input = getUserInputInt(); 
            System.out.println();
            
            // lets use select a new object and return to the main menu w/ that one displayed & current 
            if ( (input>=65 && input<=65+(mMaxLinesPerSceen/2)) ) {
                // user typed a letter to select an attribute
                //attrSelected=true;
                mEntity = mModel.getObject(attrKeys[input-65]);
                break;
            } else if (input>=97 && input <=97+(mMaxLinesPerSceen/2)) {
                // user typed a letter to select an attribute 
                //attrSelected=true;
                /*selectedAttrId = */mEntity = mModel.getObject(attrKeys[input-97]);
                break;
            } else if (input==49) { // numeral 1
                startingIndex = startingIndex + mMaxLinesPerSceen;
                if (startingIndex >= numAttrsInObject) {
                    System.out.println("End of attr list found; starting over from the beginning of the list.");
                    startingIndex=0; // start over
                }
                continue;
            } else if (input==50) { // numeral 2
                QuantityAttributeDataHolder qadh = null;
                int userChoice = -1;
                while (userChoice!=0) {
                    qadh = (QuantityAttributeDataHolder)(getAttributeDataFromUser(qadh, "quantity"));
                    if (qadh==null) {
                        break;
                    }
                    userChoice = promptWhetherTo1Add2CorrectOr0Cancel("quantity");
                    System.out.println("here 1%%");
                    if (userChoice == 1) {
                        System.out.println("here 2%%");
                        long quantityAttributeId = mEntity.addQuantityAttribute(qadh.unitId, qadh.number, qadh.attrTypeId, new Date(qadh.validOnDate.longValue()), new Date(qadh.observationDate));
                    }
                    System.out.println("here 3%%");
                }
                continue;
            } else if (input==51) { //numeral 3
                StringAttributeDataHolder sadh = null;
                int userChoice=-1;
                while (userChoice!=0) {
                    sadh = (StringAttributeDataHolder)(getAttributeDataFromUser(sadh,"string"));
                    if (sadh==null) {
                        break;
                    }
                    userChoice = promptWhetherTo1Add2CorrectOr0Cancel("string");
                    if (userChoice == 1) {
                        long textAttributeId = mEntity.addTextAttribute(sadh.text, sadh.attrTypeId, new Date(sadh.validOnDate.longValue()), new Date(sadh.observationDate));
                    }
                }
                continue;
            } else if (input==48) { // numeral 0, was 27 for ESC
                break;
            } else {
                System.out.println("unknown command: "+input);
            }
        }
        
        /* original (simpl)e version of this was:
        java.util.SortedMap attrs = mEntity.getAttributeIdsAndAttributeTypeIds(); // impl in MO as a treemap 4 now so it's sorted
        java.util.Iterator keys = attrs.keySet().iterator();
        while (keys.hasNext()) {
            Object key = keys.next(); 
            long typeId=((Long)(attrs.get(key))).longValue();
            String typeName = mModel.getObjectName(typeId);
            System.out.println(key+": "+attrs.get(key));
        }
        */
    }        
    
    private void showAttrListMenu() {    
        System.out.println("Attribute list submenu: (or choose attribute by letter)");
        System.out.println("1-List next items");
        System.out.println("2-Add \"quantity\" attribute (example: a numeric value like \"length\"");
        System.out.println("3-Add \"string\" attribute (example: a serial number, which is not added/subtracted");
        System.out.println("0-Main menu");
        System.out.println();
    }
    
    private int promptWhetherTo1Add2CorrectOr0Cancel(String inAttrTypeDesc) throws java.io.IOException {
        int reply;
        while (true) {
            System.out.println();
            System.out.println("1-Add this "+inAttrTypeDesc+" attribute?");
            System.out.println("2-Correct it?");
            System.out.println("0-Cancel?");
            reply = getUserInputInt() - 48; // converts 48=0 ascii to 0, 1, 2 etc
            if (reply < 0 || reply > 2) {
                System.out.println("invalid response: "+reply);
                continue;
            }
            break;
        }
        return reply;
    }
    
    private AttributeDataHolder getAttributeDataFromUser(AttributeDataHolder inoutDH, String inType) throws Exception {
        boolean reusePrevSettings=true;
        if (inoutDH==null) {
            if (inType=="quantity") {
                inoutDH = new QuantityAttributeDataHolder(0,0,0,new Long(0),0);
            } else {
                inoutDH = new StringAttributeDataHolder("",0,new Long(0),0);
            }
            reusePrevSettings=false;
        }
        
        boolean userWantsToCancel=false;
        
        ArrayList vals = getAttributeTypeIdFromUser(reusePrevSettings, inoutDH.attrTypeId);
        if (vals.get(0)!=null)  { 
            inoutDH.attrTypeId = ((Long)(vals.get(0))).longValue(); 
        }
        userWantsToCancel = ((Boolean)(vals.get(1))).booleanValue();
        
        if (! userWantsToCancel) {
            if (inType=="quantity") {
                userWantsToCancel = getQuantityAttributeNumberAndUnitFromUser( (QuantityAttributeDataHolder)inoutDH, reusePrevSettings);
            } else { //inType=="string"
                userWantsToCancel = getStringAttributeTextFromUser( (StringAttributeDataHolder)inoutDH );
            }
        }
        
        if (! userWantsToCancel) {
            ArrayList dates = getAttributeValidAndObservedDatesFromUser(reusePrevSettings, inoutDH.validOnDate.longValue(), inoutDH.observationDate);
            inoutDH.validOnDate = (Long)(dates.get(0));
            inoutDH.observationDate = ((Long)(dates.get(1))).longValue();
            userWantsToCancel = ((Boolean)(dates.get(2))).booleanValue();
        }
        
        if (userWantsToCancel) {
            inoutDH = null;
        }
        
        return inoutDH;
    }
    
    private boolean getStringAttributeTextFromUser(StringAttributeDataHolder inoutDH) throws Exception {
        boolean userWantsToCancel=false;
        System.out.println("Type attribute value, then press Enter; blank to cancel:");
        String input = getUserInputString();
        if (input.trim().length() > 0) {
            inoutDH.text = input;
        } else {
            userWantsToCancel=true;
        }
        return userWantsToCancel;
    }
    
    private boolean getQuantityAttributeNumberAndUnitFromUser(QuantityAttributeDataHolder inoutDH, boolean inReusePrevSettings) throws Exception {
        boolean userWantsToCancel=false;
        Long unitSelection=null;
        System.out.println();  System.out.println();
        System.out.println("SELECT A UNIT FOR THIS QUANTITY (i.e., centimeters, or quarts; blank to cancel):");
        unitSelection = displayObjectListMenuAndSelectObject((inReusePrevSettings ? new Long(inoutDH.unitId) : null));
        
        if (unitSelection==null) {
            System.out.println("Blank, so assuming you want to cancel; if not come back & add again.");
            
            userWantsToCancel=true;
        } else {
            inoutDH.unitId = unitSelection.longValue();
        }
        
        while (! userWantsToCancel) {
            System.out.println("ENTER THE NUMBER FOR THE QUANTITY (i.e., 5, for 5 centimeters length)");
            String numStr = "";
            if (inReusePrevSettings) {
                 numStr = getUserInputString(String.valueOf(inoutDH.number));
            } else {
                 numStr = getUserInputString();
            }
            if (numStr.equalsIgnoreCase("cancel")) {
                userWantsToCancel=true;
                break;
            }
            try {
                inoutDH.number = Float.parseFloat(numStr); // where the real task of getting the number happens.
                break;
            } catch (NumberFormatException e) {
                System.out.println("Not a valid number. Please try again or type \"cancel\".");
            }
        }
        return userWantsToCancel;
    }
    
    private ArrayList getAttributeTypeIdFromUser(boolean inReusePrevSettings, long inAttrTypeId)  throws Exception {
        Long attrTypeSelection=null;
        boolean userWantsToCancel=false;
        Long attrTypeId=null;
        System.out.println();  System.out.println();
        System.out.println("SELECT AN ATTRIBUTE TYPE FOR THIS QUANTITY (i.e., length, or volume; leave both blank to cancel; cancel if need to create the attribute type entity first):");
        attrTypeSelection = displayObjectListMenuAndSelectObject((inReusePrevSettings ? new Long(inAttrTypeId) : null));
        
        if (attrTypeSelection==null) {
            System.out.println("Blank, so assuming you want to cancel; if not come back & add again.");
            
            userWantsToCancel=true;
        } else {
            attrTypeId = attrTypeSelection;
        }
        
        ArrayList r = new ArrayList();
        r.add(attrTypeId);
        r.add(new Boolean(userWantsToCancel));
        return r;
    }

    
    private ArrayList getAttributeValidAndObservedDatesFromUser(boolean inReusePrevSettings, long inValidOnDate, long inObservationDate) throws Exception {
        java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("ddMMMyyyy HH:mm:ss:SSS zzz");
        String validDateStr="";
        String observationDateStr="";
        String dateErrMsg="Invalid date format. Try ddMMMyyyy, like \"15Jan2003\", or ddMMMyyyy HH:mm:ss:SSS zzz, like for just before midnight GMT, \"15Jan2003 23:59:59:999 MDT\"";
        Long validOnDate=null;
        Long observationDate=null;
        boolean userWantsToCancel=false;
        
        while (! userWantsToCancel) {
            System.out.println();  System.out.println();
            System.out.println("PLEASE ENTER THE DATE WHEN THIS WAS FIRST VALID (formatted as a subset of \"15Jan2003 23:59:59:999 MDT\"):");
            System.out.println("(For \"all time\", just press Enter. Or \"now\" for current date/time. Type \"Cancel\" to exit this.");
            validDateStr = getUserInputString();
            if (validDateStr.equalsIgnoreCase("cancel")){
                userWantsToCancel=true;
                break;
            }
            if (validDateStr==null || validDateStr.length()==0) { 
                validOnDate=null; // means "all time": see comment in user message above
            } else if ((!validDateStr.equalsIgnoreCase("now"))  &&  validDateStr.length() < 9) {// require at least ddmmmyyyy (9 chars) length
                System.out.println("Insufficient date information--at least enter the first 9 characters.");
                continue;
            } else {
                String currentDateString = dateFormat.format(new Date(System.currentTimeMillis()));
                
                if (validDateStr.equalsIgnoreCase("now")) {
                    validDateStr=currentDateString;
                }
                
                // complete the typed-in date so it has enough chars to fit the dateFormat string set up above:
                validDateStr += currentDateString.substring(validDateStr.length());
                
                // then parse it:
                Date d;
                try {
                    d = dateFormat.parse(validDateStr);//, new java.text.ParsePosition(0));
                } catch (java.text.ParseException e) {
                    System.out.println(dateErrMsg);
                    continue;
                } 
                validOnDate = new Long(d.getTime());
            }
            
            System.out.println();
            System.out.println("PLEASE ENTER THE DATE WHEN THIS INFO WAS OBSERVED");
            System.out.println("(For \"now\", just press Enter, or type \"cancel\" to get out.");
            observationDateStr = getUserInputString();
            if (observationDateStr.equalsIgnoreCase("cancel")){
                userWantsToCancel=true;
                break;
            }
            if (observationDateStr.length()==0 || observationDateStr.equalsIgnoreCase("now")) {
                observationDate = new Long(System.currentTimeMillis());
            } else {
                // complete the typed-in date so it has enough chars to fit the dateFormat string set up above:
                String currentDateString = dateFormat.format(new Date(System.currentTimeMillis()));
                observationDateStr += currentDateString.substring(observationDateStr.length());
                Date d;
                try {
                    d = dateFormat.parse(observationDateStr);
                } catch (java.text.ParseException e) {
                    System.out.println(dateErrMsg);
                    continue;
                } 
                observationDate = new Long(d.getTime());
            }
            
            break;
        }
        
        ArrayList retval = new ArrayList();
        retval.add(validOnDate);
        retval.add(observationDate);
        retval.add(new Boolean(userWantsToCancel));
        return retval;
    }

    // this method could be made more efficient in string processing, but not a big deal for now.
    /** Returns null if user chose to go to previous menu instead of choosing an object.
        The parameter "inPreviousSelection" indicate if user previously selected a value which should
        be used as the default now; if none, pass in null.
    */
    private Long displayObjectListMenuAndSelectObject(Long inPreviousSelection) throws Exception {
        //ask Model for list of obj's w/ count desired & starting index (or "first") (in a sorted map, w/ id's as key and names)
        long numObjectsInModel = mModel.getObjectCount(); // might be a little silly to do it this way, once it gets very big??
        long startingObjectIndex = 0;
        long[] keys = new long[mMaxLinesPerSceen];
        Long retval = null;
        
        while (true) {
            java.util.Map objects;
            byte cnt=0;
            objects = mModel.getEntities(startingObjectIndex, mMaxLinesPerSceen); // 1st parm is 0-based index to start with, 2nd parm is # of obj's to return.
            
            // get the keys in an array
            java.util.Iterator i = objects.keySet().iterator();
            while (i.hasNext()) {
                keys[cnt++] = ((Long)(i.next())).longValue();
            }
            
            if (!displayObjectGroup(mMaxLinesPerSceen, numObjectsInModel, startingObjectIndex, objects,null,keys,"objects",inPreviousSelection)) {
                break;
            }
            
            showObjectListMenu(inPreviousSelection);
            int input = getUserInputInt();
            System.out.println();
            
            // lets use select a new object and return to the main menu w/ that one displayed & current 
            if ( (input>=65 && input<=65+(mMaxLinesPerSceen/2)) ) {
                // user typed a letter to select an object 
                retval = new Long(keys[input-65]); //objects.get(new Long(keys[input-65])));
                break; // returns to main menu  
            } else if (input>=97 && input <=97+(mMaxLinesPerSceen/2)) {
                // user typed a letter to select an object 
                retval = new Long(keys[input-97]); //objects.get(new Long(keys[input-97])));
                break;
            } else if (input==49) { // numeral 1
                startingObjectIndex = startingObjectIndex + mMaxLinesPerSceen;
                if (startingObjectIndex >= numObjectsInModel) {
                    System.out.println("End of object list found; starting over from the beginning of the list.");
                    startingObjectIndex=0; // start over
                }
                continue;
            } else if (input==48) { // numeral 0, was 27 for ESC
                break;
            /*} else if (input==10 || input==13) { // it picked up the Enter key
                // do nothing.
                skipNextDisplay=true;*/
            } else {
                System.out.println("unknown command: "+input);
            }
        }
        
        return retval;
    }
    
    private void showObjectListMenu(Long inPreviousSelection) {    
        System.out.println("Object list submenu: (or choose object by letter)");
        if (inPreviousSelection!=null) {
            System.out.println("Or press Enter to keep previous selection.");
        }
        //System.out.println("1-Main menu");
        System.out.println("1-List next items");
        System.out.println("0-Main menu");
        System.out.println();
    }        

    /** display the object names in two columns, numbered in one column a,b,c,d etc., and in the other one like k,l,m,n,o etc. */
    private boolean displayObjectGroup(byte inMaxLinesPerSceen, long inNumObjects, long inStartingObjectIndex, 
                                    java.util.Map recentlyQueriedObjects, String[] recentlyQueriedObjectsTypes,
                                    long[] recentlyQueriedObjectsKeys, 
                                    String inType, Long inPreviousSelection) 
                                    throws Exception
    { 
        // assumes terminal width of 80.
        String dispText1=null, dispText2=null;
        byte[] letter = new byte[1];
        String letterStr;
        String promptLine;
        String spaces35 = "                                   ";
        String dispText1WithQuotes;
        String dispText2WithQuotes;
        System.out.println();
        long quantityId, typeId, unitId;
        String typeName;
        QuantityAttribute q;
        float number;
        if (inNumObjects==0) {
            if (inType.equals("objects")) {
                System.out.println("No objects have been created in this model, yet.");
            } else { //inType.equals("attrs")
                System.out.println("No attributes have been assigned to this object, yet.");
            }
            return false;
        } else {
            if (inPreviousSelection!=null) {
                System.out.print("***Previous selection: ");
                if (inType.equals("object")) {
                    System.out.println((mModel.getObject(inPreviousSelection.longValue())).getName());
                } else {
                    System.out.println(mModel.getQuantityDisplayString(inPreviousSelection.longValue()));
                }
            }
            
            for (byte cnt=0;cnt<inMaxLinesPerSceen && inStartingObjectIndex+cnt < inNumObjects; cnt++ /*cnt=(byte)(cnt+2)*/) {
                int secondColumnIndex = cnt + (inMaxLinesPerSceen/2);
                boolean do2ndColumn = (secondColumnIndex < inNumObjects);
                //if (! do2ndColumn) dispText2="";
                if (inType.equals("objects")) {
                    dispText1 = (String)(recentlyQueriedObjects.get(new Long(recentlyQueriedObjectsKeys[cnt])));
                    if (do2ndColumn) {
                        dispText2 = (String)(recentlyQueriedObjects.get(new Long(recentlyQueriedObjectsKeys[secondColumnIndex])));
                    }
                } else {
                    if (recentlyQueriedObjectsTypes[cnt].equals("text")) {
                        dispText1 = mModel.getTextDisplayString(recentlyQueriedObjectsKeys[cnt]);
                        if (do2ndColumn) {
                            dispText2 = mModel.getTextDisplayString(recentlyQueriedObjectsKeys[secondColumnIndex]);
                        }
                    } else { // "quantity": todo: this shouldn't be a hard-coded value but something encapsulated in the object!
                        dispText1 = mModel.getQuantityDisplayString(recentlyQueriedObjectsKeys[cnt]);
                        if (do2ndColumn) {
                            dispText2 = mModel.getQuantityDisplayString(recentlyQueriedObjectsKeys[secondColumnIndex]);
                        }
                    }
                    
                    /*was:
                    quantityId = recentlyQueriedObjectsKeys[cnt];
                    typeId=((Long)recentlyQueriedObjects.get(new Long(quantityId))).longValue();
                    typeName = mModel.getObjectName(typeId);
                    q = mEntity.getQuantityAttribute(quantityId);
                    number = q.getNumber();
                    unitId = q.getUnitId();
                    dispText1 = typeName+": "+number + " "+mModel.getObjectName(unitId);
                    
                    
                    quantityId = recentlyQueriedObjectsKeys[cnt + (inMaxLinesPerSceen/2)];
                    typeId=((Long)recentlyQueriedObjects.get(new Long(quantityId))).longValue();
                    typeName = mModel.getObjectName(typeId);
                    q = mEntity.getQuantityAttribute(quantityId);
                    number = q.getNumber();
                    unitId = q.getUnitId();
                    dispText2 = typeName+": "+number + " "+mModel.getObjectName(unitId);
                    */
                }
                    
                // column 1, row cnt+1: 
                letter[0] = (byte)(cnt + 97); // 97 is ascii 'a'.
                promptLine = (new String(letter)) + ") ";
                
                dispText1WithQuotes = "\""+dispText1+"\"";
                promptLine += (dispText1WithQuotes + spaces35).substring(0,34); // pad it out as needed, then shorten to fit
                promptLine += "     "; // space between the two columns
                
                // column 2:
                if (do2ndColumn) { //was if (dispText2!=null)
                    letter[0] = (byte)(letter[0] + (inMaxLinesPerSceen/2));
                    promptLine += (new String(letter)) + ") ";
                    dispText2WithQuotes = "\""+dispText2+"\"";
                    promptLine += dispText2WithQuotes.substring(0, (dispText2WithQuotes.length() <=35 ? dispText2WithQuotes.length() : 34) );
                }
                
                //together:
                System.out.println(promptLine);
            }
        }
        System.out.println();
        return true;
    }
    
    private String getUserInputString() throws java.io.IOException {
        return getUserInputString("");
    }
    private String getUserInputString(String inDefaultValue) throws java.io.IOException {
        if (inDefaultValue.length()>0) {
            System.out.print(inDefaultValue + " ");
        }
        return mSystemInputStream.readLine(); //clears the Enter key pressed after previous line's input.
    }
    private int getUserInputInt() throws java.io.IOException {
        int input = System.in.read();
        /*todo?: can override Reader class (see google sch on single-character input) to give single-char or line reading, then tweak 
            the startup script tty settings so ESC etc work? Or, will that mess up the DOS system, or will it just require a char
            in that situation? Make a quick override, build, xfer, & try it?
        */
        mSystemInputStream.readLine(); //clears the Enter key pressed after previous line's input. Why needed? Maybe prev line only gets the "int" part.
        return input;
    }
    
    private static void showCopyright() {
        String copyright="";
        copyright += "OneModel Text Interface version .001, Copyright (C) 2003 "+System.getProperty("line.separator");
        copyright += "Luke Call, and others as noted in individual source files. "+System.getProperty("line.separator");
        copyright += "OneModel comes with ABSOLUTELY NO WARRANTY; this is free "+System.getProperty("line.separator");
        copyright += "software, and you are welcome to redistribute it under "+System.getProperty("line.separator");
        copyright += "certain conditions; see the file COPYING for details."+System.getProperty("line.separator");
        System.out.println(copyright);
    }

    /** an internal convenience, only. */
    class AttributeDataHolder {
        AttributeDataHolder(long inAttrTypeId, Long inValidOnDate, long inObservationDate) {
            attrTypeId = inAttrTypeId;
            validOnDate = inValidOnDate;
            observationDate = inObservationDate;
        }
        long attrTypeId;
        Long validOnDate;//a Long not long so null value can be used to represent "all time"
        long observationDate;
    }
    /** an internal convenience, only. */
    class QuantityAttributeDataHolder extends AttributeDataHolder {
        QuantityAttributeDataHolder(float n, long inUnitId, long inAttrTypeId, Long inValidOnDate, long inObservationDate) {
            super(inAttrTypeId, inValidOnDate, inObservationDate);
            number=n;
            unitId = inUnitId;
        }
        float number;
        long unitId;
    }
    /** an internal convenience, only. */
    class StringAttributeDataHolder extends AttributeDataHolder {
        StringAttributeDataHolder(String s, long inAttrTypeId, Long inValidOnDate, long inObservationDate) {
            super(inAttrTypeId, inValidOnDate, inObservationDate);
            text = s;
        }
        String text;
    }
        
    
    private Model mModel;
    private Entity mEntity;
    private long mFirstDisplayObject;
    private java.util.prefs.Preferences mPrefs;
    private byte mMaxLinesPerSceen=24; // # of items to try to display on the screen at one time. todo: try to get it from the terminal? but that's os-dependent so not? Hm.
    private BufferedReader mSystemInputStream = new BufferedReader(new InputStreamReader(System.in));
}
