/*
    Copyright (c) 2002-2004, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

import java.util.Date;

/** Represents one object in the system.
 */
public class Entity {
    public static int getNameLength(Database inDB) {
        return inDB.getEntityNameLength();
    }
    public static boolean isDuplicate(Database inDB, String inName) throws Exception {
        return inDB.isDuplicateEntity(inName);
    }
    public static Entity createEntity(Database inDB, String inName) throws Exception {
        long id = inDB.createEntity(inName);
        Entity e = new Entity(inDB, id, false);
        return e;
    }
    
    /** This constructor instantiates an existing object from the DB. Generally use Model.createObject() to create a new object. */
    Entity(Database inDB, long inID) throws Exception {
        if (inDB.entityKeyExists(inID)) {
            mDB = inDB;
            mId = inID;
        } else {
            throw new Exception("Key "+inID+" does not exist in database."); // DON'T CHANGE this msg unless you also change the trap for it in TextUI.java.
        }
    }
    
    /** This one is perhaps only called by the database class implementation--so it can return arrays of objects & save more DB hits
        that would have to occur if it only returned arrays of keys. This DOES NOT create a persistent object--but rather should reflect
        one that already exists.
    */
    Entity(Database inDB, long inEntityId, String inName) {
        mDB = inDB;
        mId = inEntityId;
        mName = inName;
        mAlreadyReadName = true;
    }
    
    /** Allows createEntity to return an instance without duplicating the database check that it Entity(long, Database) does. */
    private Entity(Database inDB, long inID, boolean ignoreMe) throws Exception {
        mDB = inDB;
        mId = inID;
    }
    
    String getName() throws Exception {
        //maybe: see if name has been read (vars below); if so return it, if not query DB for it?
        if (! mAlreadyReadName) {
            mName=mDB.getEntityName(mId);
            mAlreadyReadName=true;
        }
        return mName;
    }
    
    IdWrapper getIdWrapper() { return new IdWrapper(mId); } 
    
    long getId() { return mId; }
    
    java.util.ArrayList getSortedAttributes(long inStartingObjectIndex, int inMaxVals) throws Exception { 
        return mDB.getSortedAttributes(mId, inStartingObjectIndex, inMaxVals);
    }
    
    long getAttrCount() throws Exception {
        return mDB.getAttrCount(mId);
    }
    
    /** Removes this object from the system. */
    void delete() throws Exception {
        mDB.deleteEntity(mId);
    }
    
    /** Creates a quantity attribute on this Entity, with default values of "now" for the dates. See Database.addQuantityAttribute(...)
        for explanation of the parameters. It might also be nice to add the recorder's ID (person or app), but we'd have to do some kind 
        of authentication/login 1st?
    */
    long /*id*/ addQuantityAttribute(long inUnitId, float inNumber, long inAttrTypeId) throws Exception {
        long defaultDate = System.currentTimeMillis();
        long validOnDate = defaultDate; // usually matches date observed; null means asserted true for all time(?)
        long observationDate = defaultDate; //map java long to postgresql bigint, for dates.
        return mDB.createQuantityAttribute(mId, inUnitId, inNumber, inAttrTypeId, new Long(validOnDate), observationDate);
    }
    
    /** For convenience--see other similarly named methods for details.
    */
    long /*id*/ addQuantityAttribute(Entity inUnit, float inNumber, Entity inAttrType) throws Exception  {
        return addQuantityAttribute(inUnit.getId(), inNumber, inAttrType.getId());
    }
    
    /** Creates a quantity attribute for this Entity (i.e., "6 inches length"). See Database.createQuantityAttribute(...) for details. 
    */
    long /*id*/ addQuantityAttribute(long inUnitId, float inNumber, long inAttrTypeId, Date inValidOnDate, Date inObservationDate) throws Exception {
        if (inObservationDate==null) {
            throw new Exception("inObservationDate should not be null");
        }
        // write it to the database table--w/ a record for all these attributes plus a key indicating which Entity
        // it all goes with
        return mDB.createQuantityAttribute(mId,inUnitId, inNumber, inAttrTypeId, new Long(inValidOnDate.getTime()), inObservationDate.getTime());
    }
    
    /** For convenience--see other similarly named methods for details.
    */
    long /*id*/ addQuantityAttribute(Entity inUnit, float inNumber, Entity inAttrType, Date inValidOnDate, Date inObservationDate) throws Exception {
        return addQuantityAttribute(inUnit.getId(), inNumber, inAttrType.getId(), inValidOnDate, inObservationDate);
    }
    
    QuantityAttribute /*qo*/ getQuantityAttribute(long inKey) throws Exception {
        return new QuantityAttribute(inKey, mDB);
    }
    
    TextAttribute /*qo*/ getTextAttribute(long inKey) throws Exception {
        return new TextAttribute(inKey, mDB);
    }
    
    /** See addQuantityAttribute(...) methods for comments. */
    long /*id*/ addTextAttribute(String inText, long inAttrTypeId) throws Exception {
        long defaultDate = System.currentTimeMillis();
        long validOnDate = defaultDate; // usually matches date observed; null means asserted true for all time(?)
        long observationDate = defaultDate; //map java long to postgresql bigint, for dates.
        return addTextAttribute(inText, inAttrTypeId, new Date(validOnDate), new Date(observationDate)); 
    }
    
    long /*id*/ addTextAttribute(String inText, long inAttrTypeId, Date inValidOnDate, Date inObservationDate) throws Exception {
        return mDB.createTextAttribute(mId, inText, inAttrTypeId, new Long(inValidOnDate.getTime()), inObservationDate.getTime());
    }
    
    void addRelationAttribute(long inAttrTypeId, long inEntityId1, long inEntityId2, Date inValidOnDate, Date inObservationDate) throws Exception {
        mDB.createRelation(inAttrTypeId, inEntityId1, inEntityId2, new Long(inValidOnDate.getTime()), inObservationDate.getTime());
    }
    
    protected long mId; // the unique ID assigned to this object in the database.
    protected Database mDB;
    protected boolean mAlreadyReadName=false;
    protected String mName;
}
