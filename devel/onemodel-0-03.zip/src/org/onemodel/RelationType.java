/*
    Copyright (c) 2002-2004, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

/** Represents one RelationType object in the system.
 */
public class RelationType extends Entity {
    
    /** This constructor instantiates an existing object from the DB. You can use Entity.addRelationTypeAttribute() to 
        create a new object.  Assumes caller just read it from the DB and the info is accurate (i.e., this may only ever need to be called by
        a Database instance?).
    */
    RelationType(Database inDB, long inEntityId) throws Exception {
        super(inDB, inEntityId);
        
        if (inDB.relationTypeKeyExists(inEntityId)) {
            mDB = inDB;
            //mEntityId = inEntityId;
            mId = inEntityId;
        } else {
            throw new Exception("Key "+inEntityId+" does not exist in database."); // DON'T CHANGE this msg unless you also change the trap for it, if used, in other code.
        }
    }
    
    /** This one is perhaps only called by the database class implementation--so it can return arrays of objects & save more DB hits
        that would have to occur if it only returned arrays of keys. This DOES NOT create a persistent object--but rather should reflect
        one that already exists.
    */
    RelationType(Database inDB, long inEntityId, String inName, String inNameInReverseDirection, String inDirectionality) {
        super(inDB, inEntityId, inName);
        mDB = inDB;
        mName = inName;
        //mEntityId = inEntityId;
        mId = inEntityId;
        mNameInReverseDirection = inNameInReverseDirection;
        mDirectionality = inDirectionality;
        mAlreadyReadData = true;
    }
    /*
    long getEntityId() throws Exception {
        // object, at least as of 1/2004, would never be instantiated w/o a key, right?
        return mEntityId;
    }*/
        
    String getNameInReverseDirection() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mNameInReverseDirection;
    }
    String getDirectionality() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mDirectionality;
    }
    String getName() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mName;
    }    
    private void readDataFromDB() throws Exception {
        String[] relationTypeData = mDB.getRelationTypeData(mId);
        /*mName = ((String)RelationTypeData.get(0));
        mNameInReverseDirection=((String)RelationTypeData.get(1));
        mDirectionality=((String)RelationTypeData.get(2));
        */
        mName = relationTypeData[0];
        mNameInReverseDirection = relationTypeData[1];
        mDirectionality = relationTypeData[2];
        
        mAlreadyReadData=true;
    }

    /** Removes this object from the system. */
    void delete() throws Exception {
        mDB.deleteRelationType(mId);
    }
    
    /* valid values for mDirectionality. */
    public static String BIDIRECTIONAL="BI";
    public static String UNIDIRECTIONAL="UNI";
    public static String NONDIRECTIONAL="NON";
    
    //private Database mDB;
    private boolean mAlreadyReadData=false;
    
    /** For descriptions of the meanings of these variables, see the comments 
        on PostgreSQLDatabase.createTables(...), and examples in the database testing code.
    */
    //private long mEntityId;
    //private String mName;
    private String mNameInReverseDirection;
    private String mDirectionality;
}
