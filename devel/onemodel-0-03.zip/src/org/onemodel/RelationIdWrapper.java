/*
    Copyright (c) 2004, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

/** See comments in class Id. This was created to make it easier for TextUI's displayObjectListMenuAndSelectObject()
    method to return a single type of value, thus can be used to display/choose from dif't types of objects,
    regardless of the type of class the returned key was for.
 */
public class RelationIdWrapper extends IdWrapper {
    public RelationIdWrapper(long inRelTypeId, long inEntityId1, long inEntityId2) {
        super(inRelTypeId);
        mId = inRelTypeId;
        mEntityId1 = inEntityId1;
        mEntityId2 = inEntityId2;
    }
    public long getId() throws Exception {
        // ok, now this is starting to feel kludgy?
        throw new Exception("For a RelationId, use getRelTypeId() instead (i.e., don't confuse the key of a relation w/ the key of another class of object).");
    }
    public long getRelTypeId() {
        return mId;
    }
    public long getEntityId1() {
        return mEntityId1;
    }
    public long getEntityId2() {
        return mEntityId2;
    }
    
    private long mEntityId1;
    private long mEntityId2;
}
