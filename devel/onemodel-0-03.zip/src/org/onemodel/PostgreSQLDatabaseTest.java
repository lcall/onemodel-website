/*
    Copyright (c) 2002-2004, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

import junit.framework.*;
import java.sql.*;
//import org.netbeans.junit.*;

/**
    PostgreSQLDatabaseTest.java: 
    JUnit based test code.
*/
public class PostgreSQLDatabaseTest extends TestCase {
    
    public PostgreSQLDatabaseTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) throws Exception {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(PostgreSQLDatabaseTest.class);
        
        return suite;
    }
    
    protected void setUp() throws Exception {
        // connect to existing database first
        mDB = new PostgreSQLDatabase();
        setupTestDBAndConnect(mDB);
    }
    
    protected void tearDown() throws Exception {
        tearDownTestDB(mDB);
    }
    
    /** This one has access permission allowing it to be called from other classes in this package, like EntityTest.
    */
    static void setupTestDBAndConnect(Database inDB) throws java.sql.SQLException {
        // create the database we want and reconnect to it
        //  first make sure it's not already there; if so drop it to clean out old data:
        try {
            inDB.destroyDatabase("testmodel");
        } catch (java.sql.SQLException e) {
            if (e.toString().indexOf("does not exist")!=-1) {
                // This is normal; nothing to clean up or worry about.
            } else {
                throw e;
            }
        }
        inDB.createDatabase("testmodel");
        inDB.connect("testmodel");
        inDB.createTables();
    }
    
    /** Has access permissions allowing to be called from other classes like EntityTest.
    */
    static void tearDownTestDB(Database inDB) throws java.sql.SQLException {
        // reconnect to the normal production database and tear down the temporary one we used for testing.
        inDB.connect("FirstModel"); //  (PostgreSQLDatabase finalizer will disconnect automatically)            
        try {
            inDB.destroyDatabase("testmodel");
        } catch (java.sql.SQLException e) {
            if (e.toString().indexOf("database \"testmodel\" is being accessed by other users")!=-1) {
                //todo: why does this happen sometimes?
                // ignore--we'll clean up when starting tests, next time through.
            } else {
                throw e;
            }
        }
    }
        
    /** Test of createEntity method, of class org.onemodel.Database. */
    public void testManyDBMethods() throws Exception {
        System.out.println("testManyDatabaseMethds");
        String name="test: org.onemodel.PostgreSQLDatabaseTest.testManyDBMethds()";
        if (name.length() > mDB.getEntityNameLength()) {
            name = name.substring(0,mDB.getEntityNameLength());
            fail("cannot use name longer than the entity name length; will truncate for remaining tests");
        }
        
        // create an entity & make sure the entity count goes up by one, and that the entity is there as expected
        // also test transactions
        mDB.beginTrans();
        long firstCount=mDB.getEntityCount();
        long id = mDB.createEntity(name);
        long newCount=mDB.getEntityCount();
        if (firstCount+1 != newCount) {
            fail("getEntityCount after adding doesn't match prior count+1! Before: "+firstCount+", after: "+newCount+".");
        }
        boolean exists = mDB.entityKeyExists(id);
        if (! exists) {
            fail("entityKeyExists after adding entity returned false.");
        }
        mDB.rollbackTrans();
        
        // now should not exist
        newCount=mDB.getEntityCount();
        if (firstCount != newCount) {
            fail("getEntityCount after rollback should match prior count! Before: "+firstCount+", after: "+newCount+".");
        }
        exists = mDB.entityKeyExists(id);
        if (exists) {
            fail("entityKeyExists after rollback returned true.");
        }
        
        // now create it again
        mDB.beginTrans();
        firstCount=mDB.getEntityCount();
        id = mDB.createEntity(name);
        // and verify it
        if (! name.equals(mDB.getEntityName(id))) {
            fail("created entity's name does not match name given.");
        }
        java.util.ArrayList entities = mDB.getEntities(0, 1); // todo: need a better (more thorough) test for getEntities() than this.
        boolean found=false;
        for (int i=0; i<entities.size(); i++) {
            if (id != ((Entity)(entities.get(i))).getId()) {
                fail("getEntities returned id that does not match the one created in the testManyDatabaseMethods().");
            }
            found=true;
            break;    
        }
        if (! found) {
            fail("getEntities() after adding entity returned nothing.");
        }
        
        
        //This section tests QuantityAttribute and many aspects of the database to make sure we have it set up right, etc.
        //and create a quantity attribute, assigned to it
        long quantityAttributeId = createTestQuantityAttributeWithTwoEntities(id);
        long quantityAttributeCount = mDB.getQuantityAttributeCount(id);
        if (quantityAttributeCount == 0) {
            fail("Creating the QuantityAttribute object reported 0 count?");
        }
        //delete the quantity attribute: #'s still right?
        long moCountBeforeQuantityDeletion = mDB.getEntityCount();
        mDB.deleteQuantityAttribute(quantityAttributeId);
        quantityAttributeCount = mDB.getQuantityAttributeCount(id);
        long moCountAfterQuantityDeletion = mDB.getEntityCount();
        if (quantityAttributeCount > 0) {
            fail("Deleting QuantityAttribute object reported > 0 count?");
        }
        if (moCountAfterQuantityDeletion!=moCountBeforeQuantityDeletion) {
            fail("Got constraint backwards? Deleting quantity attribute changed Entity count from "+moCountBeforeQuantityDeletion+" to "+moCountAfterQuantityDeletion);
        }
        // then recreate the quantity attribute (to verify its auto-deletion when Entity is deleted, below)
        quantityAttributeId = createTestQuantityAttributeWithTwoEntities(id);
        
        
        // now also test TextAttribute stuff: 
        long textAttributeId = createTestTextAttributeWithOneEntity(id);
        long textAttributeCount = mDB.getTextAttributeCount(id);
        if (textAttributeCount == 0) {
            fail("Creating the text attribute object reported 0 count?");
        }
        //delete the text attribute: #'s still right?
        long moCountBeforeTextDeletion = mDB.getEntityCount();
        mDB.deleteTextAttribute(textAttributeId);
        textAttributeCount = mDB.getTextAttributeCount(id);
        long moCountAfterTextDeletion = mDB.getEntityCount();
        if (textAttributeCount > 0) {
            fail("Deleting text attribute object reported > 0 count?");
        }
        if (moCountAfterTextDeletion!=moCountBeforeTextDeletion) {
            fail("Got constraint backwards? Deleting text attribute changed Entity count from "+moCountBeforeTextDeletion+" to "+moCountAfterTextDeletion);
        }
        // then recreate the text attribute (to verify its auto-deletion when Entity is deleted, below)
        textAttributeId = createTestTextAttributeWithOneEntity(id);
        
        
        // now also test Relationship stuff:
        long relTypeId = mDB.createRelationType(RELATION_TYPE_NAME, "", RelationType.UNIDIRECTIONAL); // also creates an entity
        long relatedEntityId = createTestRelationAttributeWithOneEntity(id, relTypeId);
        long relationAttributeCount = mDB.getRelationAttributeCount(id);
        if (relationAttributeCount == 0) {
            fail("Creating the relation attribute object reported 0 count?");
        }
        //delete the relation type & attribute: #'s still right?
        long moCountBeforeRelationDeletion = mDB.getEntityCount();
        mDB.deleteRelation(relTypeId, id, relatedEntityId);
        mDB.deleteRelationType(relTypeId);
        relationAttributeCount = mDB.getRelationAttributeCount(id);
        long moCountAfterRelationDeletion = mDB.getEntityCount();
        if (relationAttributeCount > 0) {
            fail("Deleting relation attribute object reported > 0 count?");
        }
        if (moCountAfterRelationDeletion != moCountBeforeRelationDeletion) {
            fail("Got constraint backwards? Deleting deleting Entity should delete rel type, but deleting rel type should not delete Entity; however, it changed Entity count from "+moCountBeforeRelationDeletion+" to "+moCountAfterRelationDeletion);
        }
        // then recreate the relation attribute (to verify its auto-deletion when Entity is deleted, below)
        relTypeId = mDB.createRelationType(RELATION_TYPE_NAME, "", RelationType.UNIDIRECTIONAL); // also creates an entity
        relatedEntityId = createTestRelationAttributeWithOneEntity(id, relTypeId);
        
        
        // now test that we can retrieve all of the attributes properly (whether quantity, text, or relation)
        verifyTestAttributesCreation(id);
        
        
        // now clean up & make sure that looks right also.    
        mDB.deleteEntity(id);
        mDB.deleteRelationType(relTypeId);
        newCount=mDB.getEntityCount();
        if (firstCount + 10 != newCount) { // + n because each "createTestQuantityAttributeWithTwoEntities()" (we have two) adds two (temporarily) and each "createTestTextAttributeWithOneEntity()" creates one (we also have two), plus the relation stuff (same--2).
            fail("getEntityCount after add/delete doesn't match original count! Original: "+firstCount+", after add/del: "+newCount+".");
        }
        exists = mDB.entityKeyExists(id);
        if (exists) {
            fail("entityKeyExists after deleting entity returned true.");
        }
        // also make sure that deleting the Entity automatically deleted its related attributes, and that the del rel type worked.
        if (mDB.getQuantityAttributeCount(id) > 0  ||  mDB.getTextAttributeCount(id)>0  || mDB.getRelationAttributeCount(id)>0  ||  mDB.getRelationTypeCount()>0 ) {
            fail("Deleting the model entity should also have deleted its quantity and text attribute objects. getQuantityAttributeCount(id) is "+mDB.getQuantityAttributeCount(id)+", getTextAttributeCount(id) is "+mDB.getTextAttributeCount(id)+", getRelationAttributeCount(id) is "+mDB.getRelationAttributeCount(id)+", getRelationTypeCount() is "+mDB.getRelationTypeCount()+".");
      }
        
        mDB.commitTrans();
    }
    
    public void testAddQuantityAttributeWithBadParentID() throws Exception {
        //int x=0;//test of nothing, temp.
        long badParentId = findIdWhichIsNotKeyOfAnyEntity();
        boolean gotException=false;
        
        try {
            createTestQuantityAttributeWithTwoEntities(badParentId);
        } catch (Exception e) {
            gotException=true; // desired here
            // replace for the benefit of the tester in case something does not work as expected?
            //e.printStackTrace();
        }
        
        if (! gotException) {
            fail("Database should not allow adding quantity with a bad parent (Entity) ID!");
        }
    }
    
    private long createTestQuantityAttributeWithTwoEntities(long inParentId) throws Exception {
        long unitId = mDB.createEntity("centimeters");
        long attrTypeId = mDB.createEntity(QUANTITY_TYPE_NAME);
        long defaultDate = System.currentTimeMillis();
        Long validOnDate = new Long(defaultDate);
        long observationDate = defaultDate;
        float number=50; 
        long quantityId = mDB.createQuantityAttribute(inParentId,unitId, number, attrTypeId, validOnDate, observationDate);
        
        // and verify it:
        QuantityAttribute qa = new QuantityAttribute(quantityId,mDB);
        if (qa.getParentId()!=inParentId) {
            fail("parent id not returned properly from quantity attribute? was:"+qa.getParentId()+", should be "+inParentId+".");
        }
        if (qa.getUnitId() != unitId) {
            fail("UnitId not returned properly from quantity attribute? was:"+qa.getUnitId()+", should be "+unitId+".");
        }
        if (qa.getNumber() != number) {
            fail("Number not returned properly from quantity attribute? was:"+qa.getNumber()+", should be "+number+".");
        }
        if (qa.getAttrTypeId() != attrTypeId) {
            fail("AttrTypeId not returned properly from quantity attribute? was:"+qa.getAttrTypeId()+", should be "+attrTypeId+".");
        }
        if (qa.getValidOnDate() != validOnDate.longValue()) {
            fail("ValidOnDate not returned properly from quantity attribute? was:"+qa.getValidOnDate()+", should be "+validOnDate+".");
        }
        if (qa.getObservationDate() != observationDate) {
            fail("ObservationDate not returned properly from quantity attribute? was:"+qa.getObservationDate()+", should be "+observationDate+".");
        }
        /* older way; remove it tests still pass
        java.util.ArrayList quantityData = mDB.getQuantityAttributeData(quantityId);
        long checkParentId = ((Long)quantityData.get(0)).longValue();
        if (inParentId != checkParentId) {
            fail("parent id not returned properly from quantity attribute? was:"+checkParentId+", should be "+inParentId+".");
        }
        long checkUnitId=((Long)quantityData.get(1)).longValue();
        if (checkUnitId != unitId) {
            fail("UnitId not returned properly from quantity attribute? was:"+checkUnitId+", should be "+unitId+".");
        }
        float checkNumber =((Float)quantityData.get(2)).floatValue();
        if (checkNumber != number) {
            fail("Number not returned properly from quantity attribute? was:"+checkNumber+", should be "+number+".");
        }
        long checkAttrTypeId=((Long)quantityData.get(3)).longValue();
        if (checkAttrTypeId != attrTypeId) {
            fail("AttrTypeId not returned properly from quantity attribute? was:"+checkAttrTypeId+", should be "+attrTypeId+".");
        }
        long checkValidOnDate=((Long)quantityData.get(4)).longValue();
        if (checkValidOnDate != validOnDate.longValue()) {
            fail("ValidOnDate not returned properly from quantity attribute? was:"+checkValidOnDate+", should be "+validOnDate+".");
        }
        long checkObservationDate=((Long)quantityData.get(5)).longValue();
        if (checkObservationDate != observationDate) {
            fail("ObservationDate not returned properly from quantity attribute? was:"+checkObservationDate+", should be "+observationDate+".");
        }
        // */
        
        return quantityId;
    }
    private void verifyTestAttributesCreation(long inEntityId) throws Exception {
        // (the 3rd parameter below is arbitrary; could be one (1). )
        java.util.ArrayList attrs = mDB.getSortedAttributes(inEntityId,0,15); // impl in MO as a treemap 4 now so it's sorted
        int counter = attrs.size();
        /*java.util.Iterator keys = attrs.keySet().iterator();
        int counter = 0;
        int attrsFoundCount = 0;
        String attrTypeNameOrRelatedEntityName="";
        String attrTypeNameOrRelatedEntityNames="";
        while (keys.hasNext()) {
            //Entity key = keys.next();
            counter++;
            String key = (String)(keys.next());
            long entityIdValue = ((Long)(attrs.get(key))).longValue();
            
            int hyphenLocation = key.indexOf("-");
            String attrType=key.substring(0,hyphenLocation);
            // unused but here's the info; maybe needed later.
            //String keyPartAfterTypeString = key.substring(hyphenLocation+1);
            attrTypeNameOrRelatedEntityName = mDB.getEntityName(entityIdValue);
            if (attrType.indexOf("relation") > -1) {
                if (attrTypeNameOrRelatedEntityName.equals(RELATION_NAME)) {
                    attrsFoundCount++;
                }
            } else {
                //long typeId=Long.parseLong(keyPartAfterTypeString);
                if (attrTypeNameOrRelatedEntityName.equals(QUANTITY_TYPE_NAME)) {//since that's what we added above
                    attrsFoundCount++;
                }
                if (attrTypeNameOrRelatedEntityName.equals(TEXT_TYPE_NAME)) {//since that's what we added above
                    attrsFoundCount++;
                }
            }
            attrTypeNameOrRelatedEntityName += ", ";
            attrTypeNameOrRelatedEntityNames += attrTypeNameOrRelatedEntityName;
        }
        if (attrsFoundCount!=3){
            fail("Added a \""+RELATION_NAME+"\" relationship, a \""+QUANTITY_TYPE_NAME+"\" quantity and a \""+TEXT_TYPE_NAME+"\" text attribute, but attrTypeNameOrRelatedEntityNames returned "+attrTypeNameOrRelatedEntityNames+", and attrsFoundCount = "+attrsFoundCount+"?");
        }*/
        if (counter!=3) { // we added one quantity, one text attribute and a relationship above, so it should be 3 right?
            fail("We added three attrs (relation, quantity & text), but getAttributeIdsAndAttributeTypeIds() returned "+counter+"?");
        }
    }
    private long createTestTextAttributeWithOneEntity(long inParentId) throws Exception {
        long attrTypeId = mDB.createEntity(TEXT_TYPE_NAME);
        long defaultDate = System.currentTimeMillis();
        Long validOnDate = new Long(defaultDate);
        long observationDate = defaultDate;
        String text = "some test text";
        long textAttributeId = mDB.createTextAttribute(inParentId, text, attrTypeId, validOnDate, observationDate);
        
        // and verify it:
        TextAttribute ta = new TextAttribute(textAttributeId, mDB);
        if (ta.getParentId() != inParentId) {
            fail("parent id not returned properly from text attribute? was:"+ta.getParentId()+", should be "+inParentId+".");
        }
        if (! ta.getText().equals(text)) {
            fail("Text not returned properly from text attribute? was:"+ta.getText()+", should be "+text+".");
        }
        if (ta.getAttrTypeId() != attrTypeId) {
            fail("AttrTypeId not returned properly from text attribute? was:"+ta.getAttrTypeId()+", should be "+attrTypeId+".");
        }
        if (ta.getValidOnDate() != validOnDate.longValue()) {
            fail("ValidOnDate not returned properly from text attribute? was:"+ta.getValidOnDate()+", should be "+validOnDate+".");
        }
        if (ta.getObservationDate() != observationDate) {
            fail("ObservationDate not returned properly from text attribute? was:"+ta.getObservationDate()+", should be "+observationDate+".");
        }
        /* older way; remove it tests still pass
        java.util.ArrayList textAttributeData = mDB.getTextAttributeData(textAttributeId);
        long checkParentId = ((Long)textAttributeData.get(0)).longValue();
        if (inParentId != checkParentId) {
            fail("parent id not returned properly from text attribute? was:"+checkParentId+", should be "+inParentId+".");
        }
        String checkText = (String)(textAttributeData.get(1));
        if (! checkText.equals(text)) {
            fail("Text not returned properly from text attribute? was:"+checkText+", should be "+text+".");
        }
        long checkAttrTypeId=((Long)textAttributeData.get(2)).longValue();
        if (checkAttrTypeId != attrTypeId) {
            fail("AttrTypeId not returned properly from text attribute? was:"+checkAttrTypeId+", should be "+attrTypeId+".");
        }
        long checkValidOnDate=((Long)textAttributeData.get(3)).longValue();
        if (checkValidOnDate != validOnDate.longValue()) {
            fail("ValidOnDate not returned properly from text attribute? was:"+checkValidOnDate+", should be "+validOnDate+".");
        }
        long checkObservationDate=((Long)textAttributeData.get(4)).longValue();
        if (checkObservationDate != observationDate) {
            fail("ObservationDate not returned properly from text attribute? was:"+checkObservationDate+", should be "+observationDate+".");
        }
        // */
        
        return textAttributeId;
    }
    
    private long createTestRelationAttributeWithOneEntity(long inEntityId, long inRelTypeId) throws Exception {
        long relatedEntityId = mDB.createEntity(RELATION_NAME);
        long defaultDate = System.currentTimeMillis();
        Long validOnDate = new Long(defaultDate);
        long observationDate = defaultDate;
        mDB.createRelation(inRelTypeId, inEntityId, relatedEntityId, validOnDate, observationDate);
        
        // and verify it:
        Relation rel = new Relation(inRelTypeId, inEntityId, relatedEntityId, mDB);
        if (rel.getValidOnDate() != validOnDate.longValue()) {
            fail("ValidOnDate not returned properly from relation attribute? was:"+rel.getValidOnDate()+", should be "+validOnDate+".");
        }
        if (rel.getObservationDate() != observationDate) {
            fail("ObservationDate not returned properly from relation attribute? was:"+rel.getObservationDate()+", should be "+observationDate+".");
        }
        return relatedEntityId;
    }
        
    
    private long findIdWhichIsNotKeyOfAnyEntity() throws Exception {
        long startingId=0;
        long workingId = startingId;
        while (true) {
            if (mDB.entityKeyExists(workingId)) {
                workingId++;
                if (workingId==startingId) {
                    throw new Exception("No id found which is not a key of any entity in the system. How could all id's be used??");
                }
                continue;
            } else {
                return workingId;
            }
        }
    }
    
    Database mDB;
    
    private static final String TEXT_TYPE_NAME = "someTextTypeLikeName";
    private static final String QUANTITY_TYPE_NAME = "length";
    private static final String RELATION_TYPE_NAME = "someRelationTypeName"; // i.e., owns, is-parent-of or parenthood (don't know how to name them yet), etc.
    private static final String RELATION_NAME = "someRelatedEntityName";
}
