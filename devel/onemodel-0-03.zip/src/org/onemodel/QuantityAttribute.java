/*Copyright (c) 2002-2004, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

/** Represents one quantity object in the system (usually [always, as of 9/2002] used as an attribute on a Entity). 
 */
public class QuantityAttribute extends Attribute {
    
    /** This constructor instantiates an existing object from the DB. You can use Entity.addQuantityAttribute() to 
        create a new object. 
    */
    QuantityAttribute(long inId, Database inDB) throws Exception {
        if (inDB.quantityAttributeKeyExists(inId)) {
            mDB = inDB;
            mId = inId;
        } else {
            throw new Exception("Key "+inId+" does not exist in database."); // DON'T CHANGE this msg unless you also change the trap for it, if used, in other code.
        }
    }
    /** This one is perhaps only called by the database class implementation--so it can return arrays of objects & save more DB hits
        that would have to occur if it only returned arrays of keys. This DOES NOT create a persistent object--but rather should reflect
        one that already exists.
    */
    QuantityAttribute(Database inDB, long inParentId, long inId, long inUnitId, long inNumber, long inAttrTypeId, long inDate1, long inDate2) {
        mDB = inDB;
        mParentId = inParentId;
        mId = inId;
        mUnitId = inUnitId;
        mNumber = inNumber;
        mAttrTypeId = inAttrTypeId;
        mValidOnDate = inDate1;
        mObservationDate = inDate2;
        mAlreadyReadData = true;
    }
    
    /** return smthg like "volume: 15.1 liters". For full length, pass in 0 for inLengthLimit. The parameter inParentEntity refers to the Entity whose attribute this is. 
    */
    String getDisplayString(int inLengthLimit, Entity inParentEntity/*old: long inQuantityId, Model inModel, Database inDB*/) throws Exception {
        //QuantityAttribute q = new QuantityAttribute(inQuantityId,inDB);
        String typeName = mDB.getEntityName(getAttrTypeId());
        float number = getNumber();
        long unitId = getUnitId();
        String retval =  typeName+": "+number + " "+mDB.getEntityName(unitId);
        if (inLengthLimit!=0) {
            retval = retval.substring(0,inLengthLimit);
        }
        return retval;
    }
    
    float getNumber() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mNumber;
    }
    long getUnitId() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mUnitId;
    }
    long getParentId() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mParentId;
    }
    long getAttrTypeId() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mAttrTypeId;
    }
    long getValidOnDate() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mValidOnDate;
    }
    long getObservationDate() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mObservationDate;
    }
    Database getDatabase() { return mDB; }
    
    private void readDataFromDB() throws Exception {
        java.util.ArrayList quantityData = mDB.getQuantityAttributeData(mId);
        
        mParentId=((Long)quantityData.get(0)).longValue();
        mUnitId=((Long)quantityData.get(1)).longValue();
        mNumber = ((Float)quantityData.get(2)).floatValue();
        mAttrTypeId=((Long)quantityData.get(3)).longValue();
        mValidOnDate=((Long)quantityData.get(4)).longValue();
        mObservationDate=((Long)quantityData.get(5)).longValue();
        
        mAlreadyReadData=true;
    }

    
    /** Removes this object from the system. */
    void delete() throws Exception {
        mDB.deleteQuantityAttribute(mId);
    }
    
    private Database mDB;
    private boolean mAlreadyReadData=false;
    
    /** For descriptions of the meanings of these variables, see the comments 
        on PostgreSQLDatabase.createQuantityAttribute(...) or createTables().
    */
    private long mParentId;
    //moved to Attribute class:
    //private long mId; // the unique identifier assigned to this object in the database.
    private long mUnitId;
    private float mNumber;
    private long mAttrTypeId;
    private long mValidOnDate;
    private long mObservationDate;
}
