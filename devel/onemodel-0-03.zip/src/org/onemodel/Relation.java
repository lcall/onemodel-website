/*
    Copyright (c) 2002-2004, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

/** Represents one Relation object in the system (usually [always, as of 9/2003] used as an attribute on a Entity). I can't 
    decide whether to call this Relation or RelationAttribute. You might see both terms, in various places. I think for now 
    I'll use relation to refer to Relationship data in general, and RelationAttribute when it is relative to a specific Entity.
 */
public class Relation extends Attribute {
    
    /** This constructor instantiates an existing object from the DB. You can use Entity.addRelationAttribute() to 
        create a new object.  Assumes caller just read it from the DB and the info is accurate (i.e., this may only ever need to be called by
        a Database instance?). 
    */
    Relation(long inRelTypeId, long inEntityId1, long inEntityId2, Database inDB) throws Exception {
        if (inDB.relationKeyExists(inRelTypeId, inEntityId1, inEntityId2)) {
            mDB = inDB;
            mRelTypeId = inRelTypeId;
            mEntityId1 = inEntityId1;
            mEntityId2 = inEntityId2;
        } else {
            throw new Exception("Key rel_type_id="+inRelTypeId+" and entity_id_1="+inEntityId1+" and entity_id_2="+inEntityId2+" does not exist in database."); // DON'T CHANGE this msg unless you also change the trap for it, if used, in other code.
        }
    }
    /** This one is perhaps only called by the database class implementation--so it can return arrays of objects & save more DB hits
        that would have to occur if it only returned arrays of keys. This DOES NOT create a persistent object--but rather should reflect
        one that already exists.
    */
    Relation(Database inDB, long inRelTypeId, long inEntityId1, long inEntityId2, long inValidOnDate, long inObservationDate) {
        mDB = inDB;
        mRelTypeId = inRelTypeId;
        mEntityId1 = inEntityId1;
        mEntityId2 = inEntityId2;
        mValidOnDate = inValidOnDate;
        mObservationDate = inObservationDate;
        mAlreadyReadData = true;
    }
    
    IdWrapper getIdWrapper() {
        return new RelationIdWrapper(mRelTypeId, mEntityId1, mEntityId2); 
    }
    long getId() throws Exception {
        throw new Exception("getId() operation not applicable to Relation class.");
    }
    
    long getRelTypeId() { return mRelTypeId; }
    
    long getRelatedId(long inId) throws Exception {
        if (inId == mEntityId1) {
            return mEntityId2;
        } else if (inId == mEntityId2) {
            return mEntityId1;
        } else {
            throw new Exception("Something's wrong: provided id " + inId + " doesn't match either id in the relation: "+mEntityId1+" or "+mEntityId2+".");
        }
    }
    
    /** return smthg like "son of Paul" or "owns Ford truck" or "employed by hospital". If inLengthLimit is 0 you get the whole thing.
    */
    String getDisplayString(int inLengthLimit, Entity inParentEntity/*old: long inQuantityId, Model inModel, Database inDB*/) throws Exception {
        RelationType rt = new RelationType(mDB,getRelTypeId());
        String rtName;
        if (inParentEntity.getId() == mEntityId1 || rt.getDirectionality()==rt.UNIDIRECTIONAL) {
            rtName = rt.getName();
        } else if (inParentEntity.getId() == mEntityId2) {
            rtName = rt.getNameInReverseDirection();
        } else {
            throw new Exception("Unrelated parent entity parameter?: '"+inParentEntity.getId()+"', '"+inParentEntity.getName()+"'");
        }
        String retval = rtName + " " + inParentEntity.getName();
        if (inLengthLimit!=0) {
            retval = retval.substring(0,inLengthLimit);
        }
        return retval;
    }
    
    long getValidOnDate() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mValidOnDate;
    }
    long getObservationDate() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mObservationDate;
    }
    
    private void readDataFromDB() throws Exception {
        java.util.ArrayList RelationData = mDB.getRelationData(mRelTypeId, mEntityId1, mEntityId2);
        
        mValidOnDate=((Long)RelationData.get(0)).longValue();
        mObservationDate=((Long)RelationData.get(1)).longValue();
        
        mAlreadyReadData=true;
    }

    /** Removes this object from the system. */
    void delete() throws Exception {
        mDB.deleteRelation(mRelTypeId, mEntityId1, mEntityId2);
    }
    
    private Database mDB;
    private boolean mAlreadyReadData=false;
    /** For descriptions of the meanings of these variables, see the comments 
        on PostgreSQLDatabase.createTables(...), and examples in the database testing code.
    */
    private long mRelTypeId; // \
    private long mEntityId1; //  >- these 3 fields are the unique key
    private long mEntityId2; // /
    private long mValidOnDate;
    private long mObservationDate;
}
