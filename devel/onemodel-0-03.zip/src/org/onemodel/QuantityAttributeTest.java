/*
    Copyright (c) 2002, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

import junit.framework.*;

/** Represents one quantity object in the system (usually [always, as of 9/2002] used as an attribute on a Entity). 
 */
public class QuantityAttributeTest extends TestCase {
    public QuantityAttributeTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(QuantityAttributeTest.class);
        
        return suite;
    }
    
    protected void setUp() throws Exception {
        /*
        if (mDB==null) { 
            mDB = new Database();
            PostgreSQLDatabaseTest.setupTestDBAndConnect(mDB);
            mUnitId = mDB.createEntity("centimeters");
            mAttrTypeId = mDB.createEntity("length");
            long defaultDate = System.currentTimeMillis();
            mValidOnDate = defaultDate;
            mObservationDate = defaultDate;
        }
        */
    }
    
    protected void tearDown() throws Exception {
        //PostgreSQLDatabaseTest.tearDownTestDB(mDB);
    }
    
    public void testSomething() {
        // just a stub for now
    }
    
}
