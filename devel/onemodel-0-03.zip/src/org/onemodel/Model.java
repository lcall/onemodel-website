/*
    Copyright (c) 2002-2003, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

/** This is the primary mechanism through which user interfaces or other applications
    gain access to data in the system: it is the "Model" in a model/view/controller-like 
    system. It may seem like a small, useless layer over the Database class, but it is 
    the place for any logic which is specific to the (data) "model" but which would not 
    change when we change databases (i.e., from postgresql to some other back end.). For example, 
    createEntity and getEntity wouldn't change if we change database back-ends, so they
    are here.
    
    ELIMINATING THIS CLASS FOR NOW--IS USELESS? MAYBE THE "MODEL" IS REALLY THE LAYER OF OBJECTS
    WHICH HAVE A MEMBER VARIABLE OF mDB (DATABASE IMPLEMENTOR), such as Relation, Entity,
    TextAttribute, etc. ? :

public class Model {
    Model() throws Exception {
        // could use conditional logic here to decide which database type to load!
        mDB = (Database)((Class.forName("org.onemodel.PostgreSQLDatabase")).newInstance());
    }
    
    Entity createEntity(String inName) throws Exception {
        long id = mDB.createEntity(inName.trim());
        Entity mo = new Entity(id, mDB);
        return mo;
    }
    void createRelationType(String inName, String inNameInReverseDirection, String inDirectionality) throws Exception {
        long id = mDB.createRelationType(inName.trim(), inNameInReverseDirection.trim(), inDirectionality.trim());
    }
    
    String getQuantityDisplayString(long inQuantityAttributeId) throws Exception {
        return QuantityAttribute.getDisplayString(inQuantityAttributeId, this, mDB);
    }
    
    String getTextDisplayString(long inTextAttributeId) throws Exception {
        return TextAttribute.getDisplayString(inTextAttributeId, this, mDB);
    }
    
    Entity getEntity(long inKey) throws Exception {
        return new Entity(inKey, mDB);
    }
    
    //%%was a javadoc block:
    //Allows querying for a range of entities in the database; returns a java.util.Map with keys and names. 
    //    1st parm is index to start with (0-based), 2nd parm is # of obj's to return.
        java.util.Map getEntities(long inStartingObjectIndex, int inMaxVals) throws Exception {
        return mDB.getEntities(inStartingObjectIndex, inMaxVals);
    }
    
    //%%was a javadoc block:
    // Similar to getEntities. 
    java.util.Map getRelationTypes(long inStartingObjectIndex, int inMaxVals) throws Exception {
        return mDB.getRelationTypes(inStartingObjectIndex, inMaxVals);
    }
    
    long getEntityCount() throws Exception {
        return mDB.getEntityCount();
    }
    long getRelationTypeCount() throws Exception {
        return mDB.getRelationTypeCount();
    }
    
    long getMaxIDValue() {
        return mDB.getMaxIDValue();
    }
    
    int getEntityNameLength() {
        return mDB.getEntityNameLength();
    }
    int getRelationTypeNameLength() {
        return getEntityNameLength();
    }
    
    //%%was a javadoc block:
    // Only use if you don't have or currently want an instance of the entity. If you have an
    //    instance, call "instance.getName()" instead?
    //
    String getEntityName(long inKey) throws Exception {
        return mDB.getEntityName(inKey);
    }
    
    // the two names are different because one is for the outside world that may not know that a RelationType is an Entity, so we
    // call it Entry for that (but is that simpler or more trouble overall? oh well)
    boolean isDuplicateEntry(String inStr) throws Exception {
        return mDB.isDuplicateEntity(inStr);
    }
    
    Database mDB;
}*/
/*
public class Model {
    Model() throws Exception {
        // could use conditional logic here to decide which database type to load!
        mDB = (Database)((Class.forName("org.onemodel.PostgreSQLDatabase")).newInstance());
    }
    
    Entity createEntity(String inName) throws Exception {
        long id = mDB.createEntity(inName.trim());
        Entity mo = new Entity(id, mDB);
        return mo;
    }
    void createRelationType(String inName, String inNameInReverseDirection, String inDirectionality) throws Exception {
        long id = mDB.createRelationType(inName.trim(), inNameInReverseDirection.trim(), inDirectionality.trim());
    }
    
    String getQuantityDisplayString(long inQuantityAttributeId) throws Exception {
        return QuantityAttribute.getDisplayString(inQuantityAttributeId, this, mDB);
    }
    
    String getTextDisplayString(long inTextAttributeId) throws Exception {
        return TextAttribute.getDisplayString(inTextAttributeId, this, mDB);
    }
    
    Entity getEntity(long inKey) throws Exception {
        return new Entity(inKey, mDB);
    }
    
        java.util.ArrayList getEntities(long inStartingObjectIndex, int inMaxVals) throws Exception {
        return mDB.getEntities(inStartingObjectIndex, inMaxVals);
    }
    java.util.ArrayList getRelationTypes(long inStartingObjectIndex, int inMaxVals) throws Exception {
        return mDB.getRelationTypes(inStartingObjectIndex, inMaxVals);
    }
    
    java.util.ArrayList getSortedAttributes(long inID, long inStartingObjectIndex, long inMaxVals) throws Exception {
        return mDB.getSortedAttributes(inID, inStartingObjectIndex, inMaxVals);
    }
    
    long getEntityCount() throws Exception {
        return mDB.getEntityCount();
    }
    long getRelationTypeCount() throws Exception {
        return mDB.getRelationTypeCount();
    }
    
    long getMaxIDValue() {
        return mDB.getMaxIDValue();
    }
    
    int getEntityNameLength() {
        return mDB.getEntityNameLength();
    }
    int getRelationTypeNameLength() {
        return getEntityNameLength();
    }
    
    String getEntityName(long inKey) throws Exception {
        return mDB.getEntityName(inKey);
    }
    
    // the two names are different because one is for the outside world that may not know that a RelationType is an Entity, so we
    // call it Entry for that (but is that simpler or more trouble overall? oh well)
    boolean isDuplicateEntry(String inStr) throws Exception {
        return mDB.isDuplicateEntity(inStr);
    }
    
    Database mDB;
}*/
