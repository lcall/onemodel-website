/*
    Copyright (c) 2004, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

/** Represents one attribute object in the system (usually [always, as of 1/2004] used as an attribute on a Entity). 
    Originally created as a place to put common stuff between Relation/QuantityAttribute/TextAttribute.
 */
public abstract class Attribute {
    abstract String getDisplayString(int inLengthLimit, Entity parentEntity) throws Exception;
    IdWrapper getIdWrapper() { return new IdWrapper(mId); } 
    long getId() throws Exception { return mId; }
    
    protected long mId;
}
