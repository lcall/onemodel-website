/*
    Copyright (c) 2002-2004, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

import java.sql.*;

/** 
    Any code that would change when we change storage systems (like from postgresql to 
    an object database or who knows), goes in this class. Implements the Database 
    interface.
    <br><br>
    Note that any changes to the database structures (or constraints, etc) whatsoever should 
    ALWAYS have the following: <ul>
    <li>Constraints, rules, functions, stored procedures, or triggers
    or something to enforce data integrity and referential integrity at the database level, 
    whenever possible. When this is impossible, it should be discussed on the developer mailing 
    so that we can consider putting it in the right place in the code, with the goal of 
    greatest simplicity and reliability.</li>
    <li>Put these things in the auto-creation steps of the DB class. See createDatabase() and createTables().</li>
    <li>Add comments to that part of the code, explaining the change or requirement, as needed.</li>
    <li>Any changes (as anywhere in this system) should be done in a test-first manner, for anything that
    could go wrong, along these lines:  First write a test that demonstrates the issue and fails, then 
    write code to correct the issue, then re-run the test to see the successful outcome. This helps keep our
    regression suite current, and could even help think through design issues without overcomplicating things. 
    </ul>
*/
class PostgreSQLDatabase implements Database {
    /** Creates a new instance of Database. By default, auto-commit is on unless you explicitly open a transaction; then 
        auto-commit will be off until you rollbackTrans() or commitTrans(), at which point auto-commit is 
        turned back on. 
    */
    public PostgreSQLDatabase() throws Exception  {
        Class.forName("org.postgresql.Driver");
        connect("FirstModel");
        if (! modelTablesExist()) {
            createTables();
        }
    }
    
    public void connect(String inDbName) throws java.sql.SQLException {
        try {
            if (mConn!=null) { mConn.close(); }
        } catch (Exception e) {
            // todo: anything here? log it? notify someone to see why it happened?
        }
        
        mConn = DriverManager.getConnection("jdbc:postgresql:"+inDbName, "om",null);
        mConn.setTransactionIsolation(mConn.TRANSACTION_SERIALIZABLE);
    }
    
    /** Does standard setup for a "OneModel" database, such as when starting up for the first time, or when creating a test system. */
    public void createTables() throws java.sql.SQLException {
        Statement st=null;
        Statement st2=null;
        Statement st2a=null;
        Statement st3=null;
        Statement st4=null;
        Statement st5=null;
        Statement st6=null;
        Statement st7=null;
        Statement st8=null;
        Statement st8a=null;
        Statement st9=null;
        Statement st9a=null;
        Statement st9b=null;
        try {
            st = mConn.createStatement();
            String sql = "create sequence EntityKeySequence minvalue -9223372036854775808" ;
            st.executeUpdate(sql);
            
            st2 = mConn.createStatement();
            // id must be "unique not null" in ANY database used, because it is a primary key. "PRIMARY KEY" is the same.
            sql = "create table Entity (";
            sql += "id bigint DEFAULT nextval('EntityKeySequence') PRIMARY KEY, " ;
            sql += "name varchar(60) NOT NULL ";
            sql += ") ";
            sql += "WITHOUT OIDS";
            st2.executeUpdate(sql);
            st2a = mConn.createStatement();
            sql = "create index upper_name on Entity (upper(name))";
            st2a.executeUpdate(sql);
            
            st3 = mConn.createStatement();
            sql = "create sequence QuantityAttributeKeySequence minvalue -9223372036854775808" ;
            st3.executeUpdate(sql);
            
            st4 = mConn.createStatement();
            // the parent_id is the key for the entity on which this quantity info is recorded; for other meanings see comments on
            // Entity.addQuantityAttribute(...).
            // id must be "unique not null" in ANY database used, because it is the primary key.
            sql = "create table QuantityAttribute (";
            sql += "parent_id bigint NOT NULL, ";
            sql += "id bigint DEFAULT nextval('QuantityAttributeKeySequence') PRIMARY KEY, ";
            sql += "unit_id bigint NOT NULL, ";
            sql += "quantity_number double precision not null, ";
            sql += "attr_type_id bigint not null, ";
            sql += "valid_on_date bigint not null, ";
            sql += "observation_date bigint not null, ";
            sql += "CONSTRAINT valid_unit_id FOREIGN KEY (unit_id) REFERENCES entity (id), ";
            sql += "CONSTRAINT valid_attr_type_id FOREIGN KEY (attr_type_id) REFERENCES entity (id), ";
            sql += "CONSTRAINT valid_parent_id FOREIGN KEY (parent_id) REFERENCES entity (id) ON DELETE CASCADE ";
            //sql += "ON UPDATE CASCADE "; // here for good measure?, but no test written for it. Hopefully we wuoldn't be changing those keys anyway.  
            sql += ") ";
            sql += "WITHOUT OIDS ";
            st4.executeUpdate(sql);
            
            st5 = mConn.createStatement();
            sql = "create sequence TextAttributeKeySequence minvalue -9223372036854775808" ;
            st5.executeUpdate(sql);
            
            st6 = mConn.createStatement();
            // the parent_id is the key for the entity on which this text info is recorded; for other meanings see comments on
            // Entity.addQuantityAttribute(...).
            // id must be "unique not null" in ANY database used, because it is the primary key.
            sql = "create table TextAttribute (";
            sql += "parent_id bigint NOT NULL, ";
            sql += "id bigint DEFAULT nextval('TextAttributeKeySequence') PRIMARY KEY, ";
            sql += "textValue text NOT NULL, ";
            sql += "attr_type_id bigint not null, ";
            sql += "valid_on_date bigint not null, ";
            sql += "observation_date bigint not null, ";
            sql += "CONSTRAINT valid_attr_type_id FOREIGN KEY (attr_type_id) REFERENCES entity (id), ";
            sql += "CONSTRAINT valid_parent_id FOREIGN KEY (parent_id) REFERENCES entity (id) ON DELETE CASCADE ";
            //sql += "ON UPDATE CASCADE "; // here for good measure?, but no test written for it. Hopefully we wuoldn't be changing those keys anyway.  
            sql += ") ";
            sql += "WITHOUT OIDS ";
            st6.executeUpdate(sql);
            
            st7 = mConn.createStatement();
            sql = "create sequence RelationTypeKeySequence minvalue -9223372036854775808" ;
            st7.executeUpdate(sql);
            
            // this table "inherits" from Entity (each relation type is an Entity) but we use homegrown "inheritance" for that to make it
            // easier to port to databases that don't have postgresql-like inheritance built in.  It inherits from Entity so that as Entity
            // expands (i.e., context-based naming or whatever), we'll automatically get the benefits, in objects based on this table (at least
            // that's the idea at this moment...) --Luke Call 8/2003
            st8 = mConn.createStatement();
            sql = "create table RelationType ("; // inherits from Entity; see RelationConnection for more info.
            sql += "entity_id bigint PRIMARY KEY, ";
            sql += "name_in_reverse_direction varchar(60), ";
            sql += "directionality char(3) CHECK (directionality in ('BI','UNI','NON')), ";//NOT NULL, ";//valid values are "BI ","UNI","NON"-directional for this relationship. example: parent/child is unidirectional. sibling is bidirectional, what is nondirectional?
            sql += "CONSTRAINT valid_rel_entity_id FOREIGN KEY (entity_id) REFERENCES Entity (id) ON DELETE CASCADE ";
            sql += ") ";
            sql += "WITHOUT OIDS ";
            st8.executeUpdate(sql);
            st8a = mConn.createStatement();
            sql = "create index upper_name_in_reverse_direction on RelationType (upper(name_in_reverse_direction))";
            st8a.executeUpdate(sql);
            
            // (See Relation.java for comments on why it is not named "RelationAttribute".)
            //Example: a relationship between a state and various counties might be set up like this:
            // The state and each county are Entities. A RelationType (which is an Entity with some 
            // additional columns) is bi- directional and indicates some kind of containment relationship, for example between 
            // state & counties. In the Relation table there would be a row whose rel_type_id points to the described RelationType,
            // whose entity_id_1 points to the state Entity, and whose entity_id_2 points to a given county Entity. There would be
            // additional rows for each county, varying only in the value in entity_id_2.
            // And example of something non(?)directional would be where the relationship is identical no matter which way you go, like
            // two human acquaintances). The relationship between a state and county is not the same in reverse. Haven't got a good 
            // unidirectional example, so maybe it can be eliminated? (Or maybe it would be something where the "child" doesn't "know"
            // the "parent"--like an electron in an atom? -- revu notes or see what Mark Butler thinks.
            // --Luke Call 8/2003.
            st9 = mConn.createStatement();
            sql = "create table Relation (";
            // (Not creating an artificial key here (as in TextAttribute.id, etc) so as not to artificially limit the # of possible Relation rows.)
            sql += "rel_type_id bigint NOT NULL, "; //for lookup in RelationType table (was, but is not really:  so know which RelationAttribute obj goes w/ what rows here.)
            sql += "entity_id_1 bigint NOT NULL, "; // what is related (see RelationConnection for "related to what" (related_to_entity_id)
            sql += "entity_id_2 bigint NOT NULL, "; // entity_id in RelAttr table is related to what other entity(ies)
            sql += "valid_on_date bigint not null, ";
            sql += "observation_date bigint not null, ";
            sql += "PRIMARY KEY (rel_type_id, entity_id_1, entity_id_2), ";
            sql += "CONSTRAINT valid_rel_type_id FOREIGN KEY (rel_type_id) REFERENCES RelationType (entity_id) ON DELETE CASCADE, ";
            sql += "CONSTRAINT valid_related_to_entity_id_1 FOREIGN KEY (entity_id_1) REFERENCES entity (id) ON DELETE CASCADE, ";
            sql += "CONSTRAINT valid_related_to_entity_id_2 FOREIGN KEY (entity_id_2) REFERENCES entity (id) ON DELETE CASCADE ";
            sql += ") ";
            sql += "WITHOUT OIDS ";
            st9.executeUpdate(sql);
            
            st9a = mConn.createStatement();
            sql = "create index entity_id_1 on Relation (entity_id_1)";
            st9a.executeUpdate(sql);

            st9b = mConn.createStatement();
            sql = "create index entity_id_2 on Relation (entity_id_2)";
            st9b.executeUpdate(sql);
            
        } finally {
            if (st!=null) st.close();
            if (st2!=null) st2.close();
            if (st2a!=null) st2a.close();
            if (st3!=null) st3.close();
            if (st4!=null) st4.close();
            if (st5!=null) st5.close();
            if (st6!=null) st6.close();
            if (st7!=null) st7.close();
            if (st8!=null) st8.close();
            if (st8a!=null) st8a.close();
            if (st9!=null) st9.close();
            if (st9a!=null) st9a.close();
            if (st9b!=null) st9b.close();
        }
    }
    
    /** Indicates whether the database setup has been done. */
    public boolean modelTablesExist() throws Exception {
        return doesThisExist("select count(*) from pg_class where relname='entity'");
    }        
    
    /** Used, for example, when test code is finished with its test data. Be careful. */
    public void destroyDatabase(String inDbName) throws java.sql.SQLException {
        Statement st=null;
        Statement st2=null;
        try {
            st = mConn.createStatement();
            String sql = "drop database "+inDbName ;
            st.executeUpdate(sql);
        } finally {
            if (st!=null) st.close();
        }
    }        
    
    /** Written with intent that this can be called when creating a play area for the test suite, so that production data is not disturbed. */
    public void createDatabase(String inDbName) throws java.sql.SQLException {
        Statement st=null;
        try {
            st = mConn.createStatement();
            String sql = "create database "+inDbName;
            st.executeUpdate(sql);
        } finally {
            if (st!=null) st.close();
        }
    }
        
    /** Saves data for a quantity attribute for a Entity (i.e., "6 inches length").<br>
        inParentId is the key of the Entity for which the info is being saved.<br>
        inUnitId represents a Entity; indicates the unit for this quantity (i.e., liters or inches).<br> 
        inNumber represents "how many" of the given unit.<br>
        inAttrTypeId represents the attribute type and also is a Entity (i.e., "volume" or "length")<br> 
        inValidOnDate represents the date on which this is asserted to be true (seems it would usually match the observation date); 
        null means it is asserted true for all time. inObservationDate is the date the fact was observed. <br>
        <br>
        We store the dates in
        postgresql (at least) as bigint which should be the same size as a java long, with the understanding that we are
        talking about java-style dates here; it is my understanding that such long's can also be negative to represent 
        dates long before 1970, or positive for dates long after 1970. <br>
        <br>
        In the case of inNumber, note
        that the postgresql docs give some warnings about the precision of its real and "double precision" types. Given those
        warnings and the fact that I haven't investigated carefully (as of 9/2002) how the data will be saved and read 
        between the java float type and the postgresql types, I am using "double precision" as the postgresql data type, 
        as a guess to try to lose as
        little information as possible, and I'm making this note to you the reader, so that if you care about the exactness
        of the data you can do some research and let us know what you find, at om-list@onemodel.org.
    */
    public long /*id*/ createQuantityAttribute(long inParentId, long inUnitId, float inNumber, long inAttrTypeId, Long inValidOnDate, long inObservationDate) throws Exception {
        long id = getNewKey("QuantityAttributeKeySequence");
        String sql = "insert into QuantityAttribute values (" + inParentId + "," + id + "," + inUnitId + "," + inNumber + "," + inAttrTypeId + "," + inValidOnDate.longValue() + "," + inObservationDate + ")";
        createObject(sql);
        return id;        
    }
    
    public long /*id*/ createTextAttribute(long inParentId, String inText, long inAttrTypeId, Long inValidOnDate, long inObservationDate) throws Exception {
        long id = getNewKey("TextAttributeKeySequence");
        String sql = "insert into TextAttribute values (" + inParentId + "," + id + ",'" + inText + "'," + inAttrTypeId + "," + inValidOnDate.longValue() + "," + inObservationDate + ")";
        createObject(sql);
        return id;        
    }
    
    public void createRelation(long inRelationTypeId, long inEntityId1, long inEntityId2, Long inValidOnDate, long inObservationDate) throws Exception { 
        String sql = "INSERT INTO Relation VALUES ("+inRelationTypeId+","+inEntityId1+", "+inEntityId2+", " + inValidOnDate.longValue() + "," + inObservationDate + ")";
        createObject(sql);
    }
    
    public long /*id*/ createEntity(String inName) throws Exception {
        if (inName==null || inName.length()==0) {
            throw new Exception("Name must have a value.");
        }
        long id = getNewKey("EntityKeySequence");
        String sql = "INSERT INTO Entity VALUES ("+id+",'"+inName+"')";
        createObject(sql);
        return id;
    }
    
    public long /*id*/ createRelationType(String inName, String inNameInReverseDirection, String inDirectionality) throws Exception {
        if (inName==null || inName.length()==0) {
            throw new Exception("Name must have a value.");
        }
        
        beginTrans();
        
        long id=0;
        try {
            id = getNewKey("EntityKeySequence");
            String sql = "INSERT INTO Entity VALUES ("+id+",'"+inName+"')";
            createObject(sql);
            sql = "INSERT INTO RelationType VALUES ("+id+",'"+inNameInReverseDirection+"','"+inDirectionality+"')";
            createObject(sql);
        } catch (Exception e) {
            rollbackTrans();
            throw e;
        }
        
        commitTrans();
        
        return id;
    }
        
    
    public void deleteEntity(long inID) throws Exception {
        deleteObject("Entity",inID);
    }
    
    public void deleteQuantityAttribute(long inID) throws Exception {
        deleteObject("QuantityAttribute",inID);
    }
    
    public void deleteTextAttribute(long inID) throws Exception {
        deleteObject("TextAttribute",inID);
    }
    public void deleteRelation(long inRelTypeId, long inEntityId1, long inEntityId2) throws Exception {
        deleteObjectBySpecifyingWhereClause("Relation","where rel_type_id="+inRelTypeId+" and entity_id_1="+inEntityId1+" and entity_id_2="+inEntityId2);
    }
    public void deleteRelationType(long inID) throws Exception {
        deleteObjectBySpecifyingWhereClause("RelationType","where entity_id="+inID);
    }
    
    
    public long getEntityCount() throws Exception {
        return countRows("SELECT count(1) from Entity");
    }
    public long getRelationTypeCount() throws Exception {
        return countRows("select count(1) from RelationType");
    }
    
    public long getQuantityAttributeCount(long inEntityId) throws Exception {
        return countRows("select count(1) from QuantityAttribute where parent_id="+inEntityId);
    }

    public long getTextAttributeCount(long inEntityId) throws Exception {
        return countRows("select count(1) from TextAttribute where parent_id="+inEntityId);
    }

    public long getRelationAttributeCount(long inEntityId) throws Exception {
        return countRows("select count(1) from Relation where entity_id_1="+inEntityId);
    }

    public java.util.ArrayList getQuantityAttributeData(long inQuantityId) throws Exception {
        Statement st=null;
        ResultSet rs=null;
        boolean loopedOnce=false;
        java.util.ArrayList retval = new java.util.ArrayList();
        try {
            st = mConn.createStatement();
            rs = st.executeQuery("select parent_id, unit_id, quantity_number, attr_type_id, valid_on_date, observation_date from QuantityAttribute where id="+inQuantityId);
            while(rs.next()) {
                if (loopedOnce) {
                    throw new Exception("More than one QuantityAttribute results from query on QuantityAttribute id "+inQuantityId+"??");
                }
                // todo: this would be more efficient if we return an array instead of creating/reading all these
                // temporary objects!--but then what do about the Float value?
                retval.add(new Long(rs.getLong(1)));
                retval.add(new Long(rs.getLong(2)));
                retval.add(new Float(rs.getFloat(3)));
                retval.add(new Long(rs.getLong(4)));
                retval.add(new Long(rs.getLong(5)));
                retval.add(new Long(rs.getLong(6)));
                loopedOnce=true;
            }
        } finally {
            if (rs!=null) rs.close();
            if (st!=null) st.close();
        }
        return retval;
    }

    public java.util.ArrayList getRelationData(long inRelTypeId, long inEntityId1, long inEntityId2) throws Exception {
        Statement st=null;
        ResultSet rs=null;
        boolean loopedOnce=false;
        java.util.ArrayList retval = new java.util.ArrayList();
        try {
            st = mConn.createStatement();
            rs = st.executeQuery("select valid_on_date, observation_date from Relation where rel_type_id="+inRelTypeId+" and entity_id_1="+inEntityId1+" and entity_id_2="+inEntityId2);
            while(rs.next()) {
                if (loopedOnce) {
                    throw new Exception("More than one relation results from query where rel_type_id="+inRelTypeId+" and entity_id_1="+inEntityId1+" and entity_id_2="+inEntityId2+"??");
                }
                // todo: this would be more efficient if we return an array instead of creating/reading all these temporary objects?
                retval.add(new Long(rs.getLong(1)));
                retval.add(new Long(rs.getLong(2)));
                loopedOnce=true;
            }
        } finally {
            if (rs!=null) rs.close();
            if (st!=null) st.close();
        }
        
        /*//OBSOLETE SECTION:
        then get the RelationConnection info for each of the RelationAttributes found (fix all the below, depending on what decided just above)
        for (int i=0;i<retval.size();i++) {
            try {
                st = mConn.createStatement();
                rs = st.executeQuery("select name, related_entity_id, directionality from RelationAttribute where id="+inRelationId);
                while(rs.next()) {
                    if (loopedOnce) {
                        throw new Exception("More than one RelationAttribute results from query on RelationAttribute id "+inRelationId+"??");
                    }
                    // todo: this would be more efficient if we return an array instead of creating/reading all these temporary objects
                    retval.add(rs.getString(1));
                    retval.add(new Long(rs.getLong(2)));
                    retval.add(rs.getString(3));
                    loopedOnce=true;
                }
            } finally {
                if (rs!=null) rs.close();
                if (st!=null) st.close();
            }
        }*/
        return retval;
    }

    public String[] getRelationTypeData(long inId) throws Exception {
        Statement st=null;
        ResultSet rs=null;
        boolean loopedOnce=false;
        //java.util.ArrayList retval = new java.util.ArrayList();
        String[] retval = new String[3];
        try {
            st = mConn.createStatement();
            rs = st.executeQuery("select name, name_in_reverse_direction, directionality from RelationType r, Entity e where e.id=r.entity_id and r.entity_id="+inId);
            while(rs.next()) {
                if (loopedOnce) {
                    throw new Exception("More than one RelationType results from query on id "+inId+"??");
                }
                /*// todo: this would be more efficient if we return an array instead of creating/reading all these
                // temporary objects!--but then what do about the Long value?
                retval.add(rs.getString(1)));
                retval.add(rs.getString(2));
                retval.add(rs.getString(3));
                */
                retval[0] = rs.getString(1);
                retval[1] = rs.getString(2);
                retval[2] = rs.getString(3);
                loopedOnce=true;
            }
        } finally {
            if (rs!=null) rs.close();
            if (st!=null) st.close();
        }
        return retval;
    }

    public java.util.ArrayList getTextAttributeData(long inTextId) throws Exception {
        Statement st=null;
        ResultSet rs=null;
        boolean loopedOnce=false;
        java.util.ArrayList retval = new java.util.ArrayList();
        try {
            st = mConn.createStatement();
            rs = st.executeQuery("select parent_id, textValue, attr_type_id, valid_on_date, observation_date from TextAttribute where id="+inTextId);
            while(rs.next()) {
                if (loopedOnce) {
                    throw new Exception("More than one TextAttribute results from query on TextAttribute id "+inTextId+"??");
                }
                // todo: this would be more efficient if we return an array instead of creating/reading all these
                // temporary objects!--but then what do about the Float value?
                retval.add(new Long(rs.getLong(1)));
                retval.add(rs.getString(2));
                retval.add(new Long(rs.getLong(3)));
                retval.add(new Long(rs.getLong(4)));
                retval.add(new Long(rs.getLong(5)));
                loopedOnce=true;
            }
        } finally {
            if (rs!=null) rs.close();
            if (st!=null) st.close();
        }
        return retval;
    }

    public boolean quantityAttributeKeyExists(long inID) throws Exception {
        return doesThisExist("SELECT count(1) from QuantityAttribute where id="+inID);
    }
    
    public boolean textAttributeKeyExists(long inID) throws Exception {
        return doesThisExist("SELECT count(1) from TextAttribute where id="+inID);
    }
    
    public boolean entityKeyExists(long inID) throws Exception {
        return doesThisExist("SELECT count(1) from Entity where id="+inID);
    }
    
    public boolean relationTypeKeyExists(long inId) throws Exception {
        return doesThisExist("SELECT count(1) from RelationType where entity_id="+inId);
    }
    
    public boolean relationKeyExists(long inRelTypeId, long inEntityId1, long inEntityId2) throws Exception {
        return doesThisExist("SELECT count(1) from Relation where rel_type_id="+inRelTypeId+" and entity_id_1="+inEntityId1+" and entity_id_2="+inEntityId2);
    }
    
    public int getEntityNameLength() {
        return 60; //Might be nice to figure out how to do this by querying the DB, then writing a test for it. 
    }
    
    /** Allows querying for a range of objects in the database; returns a java.util.Map with keys and names. 
        1st parm is index to start with (0-based), 2nd parm is # of obj's to return.
    */
    public java.util.ArrayList getEntities(long inStartingObjectIndex, int inMaxVals) throws Exception {
        return getEntitiesGeneric(inStartingObjectIndex, inMaxVals, "Entity");
    }
    /* Retrieves only those entities that are not also something else (not RelationTypes, QuantityTypes, units etc). */
    public java.util.ArrayList getEntitiesOnly(long inStartingObjectIndex, int inMaxVals) throws Exception {
        return getEntitiesGeneric(inStartingObjectIndex, inMaxVals, "EntityOnly");
    }
    
    /** similar to getEntities */
    public java.util.ArrayList getRelationTypes(long inStartingObjectIndex, int inMaxVals) throws Exception {
        return getEntitiesGeneric(inStartingObjectIndex, inMaxVals, "RelationType");
    }
    private java.util.ArrayList getEntitiesGeneric(long inStartingObjectIndex, int inMaxVals, String inTableName) throws Exception {
        java.util.ArrayList retval = new java.util.ArrayList();
        Statement st=null;
        ResultSet rs=null;
        String name = null;
        long seq = 0;
        try {
            st = mConn.createStatement();
            String entitySelectPart = "SELECT e.id, e.name";
            String sql = entitySelectPart;
            if (inTableName.compareToIgnoreCase("RelationType")==0) {
                sql += ", name_in_reverse_direction, directionality ";
            }
            sql += " from Entity e ";
            if (inTableName.compareToIgnoreCase("RelationType")==0) {
                // for rel  ations, hit both tables since one "inherits", but limit it to those rows
                // for which a RelationType row also exists.
                sql += ", RelationType where Entity.id = RelationType.entity_id ";
            }
            if (inTableName.compareToIgnoreCase("EntityOnly")==0) {
                sql += "except ("+ entitySelectPart + " from entity e, quantityattribute q where e.id=q.unit_id) ";
                sql += "except ("+ entitySelectPart + " from entity e, quantityattribute q where e.id=q.attr_type_id) ";
                sql += "except ("+ entitySelectPart + " from entity e, textattribute t where e.id=t.attr_type_id) ";
                sql += "except ("+ entitySelectPart + " from entity e, relationtype t where e.id=t.entity_id) ";
            }
            sql += " order by id limit "+inMaxVals+" offset "+inStartingObjectIndex;
            rs = st.executeQuery(sql);
            boolean gotIt=false;
            while(rs.next()) {
                if (inTableName.compareToIgnoreCase("RelationType")==0) {
                    retval.add(new RelationType(this, rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4)));
                } else {
                    retval.add(new Entity(this,rs.getLong(1), rs.getString(2)));
                }
                gotIt=true;
            }
            /* removed: there could be 0 rows when user 1st starts using system
            if (! gotIt) {
                throw new Exception("Failed to get any rows for inStartingObjectIndex "+inStartingObjectIndex+" and inMaxVals "+inMaxVals+"."); 
            }*/
        } finally {
            if (rs!=null)  rs.close();
            if (st!=null) st.close();
        }
        return retval;
    }

    public String getEntityName(long inID) throws Exception { 
        Statement st=null;
        ResultSet rs=null;
        String retval=null;
        try {
            st = mConn.createStatement();
            rs = st.executeQuery("SELECT name from Entity where id="+inID);
            boolean gotIt=false;
            while(rs.next()) {
                retval=rs.getString(1);
                gotIt=true;
                break;
            }
            if (! gotIt) {
                throw new Exception("Failed to get name for key '"+inID+"'!"); 
            }
        } finally {
            if (rs!=null)  rs.close();
            if (st!=null) st.close();
        }
        return retval;
    }
    
    public java.util.ArrayList getSortedAttributes(long inID, long inStartingObjectIndex, long inMaxVals) throws Exception { 
        Statement st=null;
        ResultSet rs=null;
        /*Statement st2=null;
        ResultSet rs2=null;
        Statement st3=null;
        ResultSet rs3=null;
        Statement st4=null;
        ResultSet rs4=null;
        long value=0, val1=0, val2=0, val3=0;
        String desc="", key="";*/
        java.util.ArrayList retval = new java.util.ArrayList();
        // note: pgsql docs say "Under the JDBC specification, you should access a field only once." (under the JDBC interface part)
        
        // 1st select counts from each table, keep a running total so we know when to select attrs (compared to inStartingObjectIndex)
        // and when to stop
        String[] tables = {"QuantityAttribute", "TextAttribute","Relation","Relation"};
        String[] columnsSelectedByTable = {"parent_id,id,unit_id,quantity_number,attr_type_id,valid_on_date,observation_date",
                                    "parent_id,id,textValue,attr_type_id,valid_on_date,observation_date",
                                    "rel_type_id,entity_id_1,entity_id_2,valid_on_date,observation_date",
                                    "rel_type_id,entity_id_1,entity_id_2,valid_on_date,observation_date"
                                    };
        String[] whereClausesByTable = new String[tables.length];
        whereClausesByTable[0] = "parent_id="+inID;
        whereClausesByTable[1] = "parent_id="+inID;
        whereClausesByTable[2] = "entity_id_1="+inID;
        whereClausesByTable[3] = "entity_id_2="+inID;
        String[] orderByClausesByTable = new String[tables.length];
        orderByClausesByTable[0] = "id";
        orderByClausesByTable[1] = "id";
        orderByClausesByTable[2] = "entity_id_1";
        orderByClausesByTable[3] = "entity_id_2";
        int tableListIndex=0;
        int counter = 0;//keeps track of where we are in getting rows >= inStartingObjectIndex and <= inMaxVals
        /*System.out.println("counter: " + counter);
        System.out.println("inStartingObjectIndex: " + inStartingObjectIndex);
        System.out.println("inMaxVals: " + inMaxVals);
        */
        while (counter-inStartingObjectIndex  <=  inMaxVals  &&  tableListIndex<tables.length) {
            long thisTablesRowCount = countRows("select count(*) from "+tables[tableListIndex]+" where "+whereClausesByTable[tableListIndex]);
            if (thisTablesRowCount>0  &&  counter+thisTablesRowCount >= inStartingObjectIndex) {
                try {
                    // Note: could speed this query up in part? by doing on each query something like: 
                    //              limit inMaxVals+" offset "+ inStartingObjectIndex-counter;
                    // ..and then incrementing the counters appropriately.
                    String sql = "select "+columnsSelectedByTable[tableListIndex]+" from "+tables[tableListIndex]+" where "+whereClausesByTable[tableListIndex]+" order by "+orderByClausesByTable[tableListIndex];
                    st = mConn.createStatement();
                    rs = st.executeQuery(sql);
                    // skip past those that are outside the range to retrieve
                    while (counter < inStartingObjectIndex && rs.next()) {
                        counter++;
                    }
                    while (counter <= inStartingObjectIndex+inMaxVals && rs.next()) {
                        if (tables[tableListIndex]=="QuantityAttribute") {
                            retval.add(new QuantityAttribute(this, rs.getLong(1),rs.getLong(2),rs.getLong(3),rs.getLong(4),rs.getLong(5),rs.getLong(6),rs.getLong(7)));
                        } else if (tables[tableListIndex]=="TextAttribute") {
                            retval.add(new TextAttribute(this, rs.getLong(1),rs.getLong(2),rs.getString(4),rs.getLong(4),rs.getLong(5),rs.getLong(6)));
                        } else if (tables[tableListIndex]=="Relation") {
                            retval.add(new Relation(this, rs.getLong(1),rs.getLong(2),rs.getLong(3),rs.getLong(4),rs.getLong(5)));
                        } else if (tables[tableListIndex]=="Relation") {
                            retval.add(new Relation(this, rs.getLong(1),rs.getLong(2),rs.getLong(3),rs.getLong(4),rs.getLong(5)));
                        } else {
                            throw new Exception("invalid table type?: '"+tables[tableListIndex]+"'");
                        }
                        counter++;
                    }
                } finally {
                    if (rs!=null) rs.close();
                    if (st!=null) st.close();
                    rs = null;
                    st = null;
                }
            } else {
                counter += thisTablesRowCount;
            }
            tableListIndex++;
        }
        
        // OLD VERSION: doesn't allow building an object for each return type (maybe desirable in some cases but will depend on performance needs?)
        // then at the table(s) where we need to get the objects, and do the query and get them and build the array w/ them (fully
        // constructed, like RelationType did in earlier coding session--constructor w/ all parms), and pass them back
        
        // build the relation-from obj's in reverse--swap name and reverse-name, etc., so the objects will work as expected when passed
        // to the display function--they are logically equivalent to storing it in reverse in the DB, so are OK, right?
        /* replacing this w/ calls that build the right # of *objects* rather than passing back strings to parse
        st = mConn.createStatement();
        String sql = "SELECT 'quantity',      id,             attr_type_id,id    from QuantityAttribute where parent_id="+inID;
        sql += " UNION SELECT 'text',         id,             attr_type_id,id   from TextAttribute where parent_id="+inID; 
        sql += " UNION SELECT 'relation-to',  entity_id_1,    entity_id_2, rel_type_id from Relation where entity_id_1="+inID;
        sql += " UNION SELECT 'relation-from',entity_id_1,    entity_id_2, rel_type_id from Relation where entity_id_2="+inID;
        sql += " order by 1 limit "+inMaxVals+" offset "+inStartingObjectIndex;
        rs = st.executeQuery(sql);
        while(rs.next()) {
            desc = rs.getString(1);
            val1 = rs.getLong(2); // the id or entity_id_1
            val2 = rs.getLong(3); // the attr_type_id or the entity_id_2
            val3 = rs.getLong(4);
            if (desc.indexOf("relation") > -1) {
                key = desc + "-" + val1 + "-" + val2 + "-" + val3;
                if (desc.equals("relation-to")) {
                    value = val2;
                } else { // "relation-from"
                    value = val1;
                }
            } else { // text or quantity
                key = desc + "-" + val1;
                value = val2;
            }
            retval.put(key, new Long(value));
        }*/
        
        /* older: doesn't handle inMaxVals & inStartingObjectIndex properly, and too many break stmts!??
        st = mConn.createStatement();
        rs = st.executeQuery("SELECT id, attr_type_id from QuantityAttribute where parent_id="+inID+" order by id limit "+inMaxVals+" offset "+inStartingObjectIndex);
        while(rs.next()) {
            id=rs.getLong(1);
            attrTypeId=rs.getLong(2);
            retval.put("quantity-"+rs.getLong(1), new Long(attrTypeId));
            break;
        }
        st2 = mConn.createStatement();
        rs2 = st.executeQuery("SELECT id, attr_type_id from TextAttribute where parent_id="+inID+" order by id limit "+inMaxVals+" offset "+inStartingObjectIndex);
        while(rs2.next()) {
            id=rs2.getLong(1);
            attrTypeId=rs2.getLong(2);
            retval.put("text-"+rs2.getLong(1), new Long(attrTypeId));
            break;
        }
        st3 = mConn.createStatement();
        rs3 = st.executeQuery("SELECT entity_id_1, entity_id_2 from Relation where entity_id_1="+inID+" order by entity_id_1 limit "+inMaxVals+" offset "+inStartingObjectIndex);
        while(rs3.next()) {
            id=rs3.getLong(1);
            retval.put("relation-"+rs3.getLong(1), new Long(rs3.getLong(2)));
            break;
        }
        st4 = mConn.createStatement();
        rs4 = st.executeQuery("SELECT entity_id_2, entity_id_1 from Relation where entity_id_2="+inID+" order by entity_id_2 limit "+inMaxVals+" offset "+inStartingObjectIndex);
        while(rs4.next()) {
            id=rs4.getLong(1);
            retval.put("relation-"+rs4.getLong(1), new Long(rs4.getLong(2)));
            break;
        }
        //*/
        return retval;
    }
    
    public long getAttrCount(long inID) throws Exception {
        return countRows("SELECT count(1) from QuantityAttribute where parent_id="+inID);
    }
    
    public boolean isDuplicateEntity(String inName) throws Exception {
        boolean one = doesThisExist("SELECT count(1) from Entity where upper(name)='"+inName.toUpperCase()+"'");
        boolean two = doesThisExist("SELECT count(1) from RelationType where upper(name_in_reverse_direction)='"+inName.toUpperCase()+"'");
        //System.out.println("******* one is "+one); // ??
        //System.out.println("******* two is "+two+", "+inName);
        //System.out.println("one or two: "+(one || two));
        return (one || two);
    }
    
    /** Like jdbc's default, if you don't call begin/rollback/commit, it will commit after every stmt, 
        using the defa behavior of jdbc; but if you call begin/rollback/commit, it will let you manage 
        explicitly and will automatically turn autocommit on/off as needed to allow that. 
    */
    public void beginTrans() throws java.sql.SQLException {
        mConn.setAutoCommit(false); // implicitly begins a transaction, according to jdbc documentation
    }    
    public void rollbackTrans() throws java.sql.SQLException {
        mConn.rollback();
        mConn.setAutoCommit(true); // so future work is auto- committed unless programmer explicitly opens another transaction
    }
    public void commitTrans() throws java.sql.SQLException {
        mConn.commit();
        mConn.setAutoCommit(true); // so future work is auto- committed unless programmer explicitly opens another transaction
    }
    
    public long getMaxIDValue() {
        // Max size for a Java long type, and for a postgresql 7.2.1 bigint type (which is being used, at the moment, for the id value in Entity table.
        return 9223372036854775807l; // (ends w/ 'l' (lowercase L) for long) 
    }
    
    protected void finalize() throws java.sql.SQLException {
        if (mConn!=null) { mConn.close(); }
    }
    
    private long countRows(String inSQL) throws Exception {
        Statement st=null;
        ResultSet rs=null;
        long retval=0;
        try {
            st = mConn.createStatement();
            rs = st.executeQuery(inSQL);
            boolean gotIt=false;
            while(rs.next()) {
                retval = rs.getLong(1);
                gotIt=true;
                break;
            }
            if (! gotIt) {
                throw new Exception("Failed to get row count!"); 
            }
        } finally {
            if (rs!=null)  rs.close();
            if (st!=null) st.close();
        }
        return retval;
    }
    
    /** Convenience function. Error message it gives if > 1 found assumes that sql passed in will return only 1 row! */
    private boolean doesThisExist(String inSql) throws Exception {
        long rowcnt = countRows(inSql);
        boolean retval = false;
        if (rowcnt==1) {
            retval=true;
        } else if (rowcnt > 1) {
            throw new Exception("Should there be > 1 entries for sql: "+inSql+"??  ("+rowcnt+" were found.)");
        }
        return retval;
    }
    
    private void createObject(String inSQL) throws Exception {
        Statement st2=null;
        int rowsInserted =0;
        try {            
            st2 = mConn.createStatement();
            rowsInserted = st2.executeUpdate(inSQL);
        } finally {
            if (st2!=null) st2.close();
        }
        if (rowsInserted!=1) {
            throw new Exception("Inserted "+rowsInserted+" rows instead of 1? SQL was: "+inSQL);
        }
    }
    private void deleteObjectBySpecifyingWhereClause(String inTableName, String inWhereClause) throws Exception {
        Statement st=null;
        beginTrans();
        try {
            st = mConn.createStatement();
            String sql = "DELETE FROM "+inTableName+" "+inWhereClause;
            int rowsdeleted = st.executeUpdate(sql);
            if (rowsdeleted!=1) {
                rollbackTrans();
                throw new Exception("Deleted "+rowsdeleted+" when it should have deleted 1!  Therefore transaction has been (right?) rolled back.  SQL was: "+sql);
            }
        } finally {
            if (st!=null) st.close();
        }
        commitTrans();
    }
    private void deleteObject(String inTableName, long inID) throws Exception {
        Statement st=null;
        beginTrans();
        try {
            st = mConn.createStatement();
            String sql = "DELETE FROM "+inTableName+" where id="+inID;
            int rowsdeleted = st.executeUpdate(sql);
            if (rowsdeleted!=1) {
                rollbackTrans();
                throw new Exception("Deleted "+rowsdeleted+" when it should have deleted 1!  Therefore transaction has been (right?) rolled back.  SQL was: "+sql);
            }
        } finally {
            if (st!=null) st.close();
        }
        commitTrans();
    }
    
    /** although the next sequence value would be set automatically as the default for a column (at least the
        way I have them defined so far in postgresql); we do it explicitly by retrie
        so we know what sequence value to return, and what the unique key is of the row we just created!
    */
    private long /*id*/ getNewKey(String inSequenceName) throws Exception {
        Statement st=null;
        ResultSet rs=null;
        long id=0;
        try {
            st = mConn.createStatement();
            rs = st.executeQuery("SELECT nextval('"+inSequenceName+"')");
            boolean gotIt=false;
            while(rs.next()) {
                id=rs.getLong(1);
                gotIt=true;
                break;
            }
            if (! gotIt) {
                throw new Exception("Failed to get new id (sequence) number; cannot insert row."); 
            }
        } finally {
            if (rs!=null) rs.close();
            if (st!=null) st.close();
        }
        return id;
    }
    
    private Connection mConn;
 }
