/*
    Copyright (c) 2004, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

/** Represents the unique ID (key) for an Entity or Attribute object in the system. Benefit is that we can return
    one of these from a method and the signature of the method does not have to specify whether it is
    the ID of a QuantityAttribute, Relation, etc (relation ID has  3 parts, Attribute and Entity ID's  for example have one).
 */
public class IdWrapper {
    public IdWrapper(long l) { mId = l; }
    
    public long getId() throws Exception { 
        //if (false) throw new Exception("");//just a stub so can throw one in the inherited method of RelationIdWrapper: better approach??
        return mId; 
    }
    
    protected long mId;
}
