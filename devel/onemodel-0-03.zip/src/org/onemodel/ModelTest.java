/*
    Copyright (c) 2002-2003, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

import junit.framework.*;

/** Uses junit for tests.
*/
public class ModelTest extends TestCase {
    
    public ModelTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(ModelTest.class);
        
        return suite;
    }
    
    /** just to avoid an error, until we have some actual test here. */
    public void testNothing() {
    }
    
    /** Test of addObject method, of class org.onemodel.Model. */
    /*public void testCreateAndDestroyObject() {
        System.out.println("testAddObject");
        
        Model m = new Model();
        long dbSize = m.getSize();
        
        String name="testCreateAndDestroyObject: deleteme";
        Entity newEntity = m.createObject(name);
        String newObjName = newMO.getName();
        if (! name.equals(newObjName)) {
            fail("New name doesn't match name assigned to the object.");
        }
        
        if (m.getSize() <= dbSize) {
            fail("db size should have grown when we added an object");
        }
        
        newMO.destroy();
        
        if (m.getSize() != dbSize) {
            fail("db size should be equal after adding then deleting an object (unless multiuser now)");
        }
    }*/
    
    // Add test methods here, they have to start with 'test' name.
    // for example:
    // public void testHello() {}
    
    
}
