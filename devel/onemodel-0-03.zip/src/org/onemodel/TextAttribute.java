/*
    Copyright (c) 2002-2004, Luke Call and any other authors, whether or not they chose to comment their code with their name.
    All rights reserved. Distributed under the GPL; see the file COPYING for details. 
*/

package org.onemodel;

/** Represents one String object in the system (usually [always, as of 9/2002] used as an attribute on a Entity). 
 */
public class TextAttribute extends Attribute {
    
    /** This constructor instantiates an existing object from the DB. You can use Entity.addTextAttribute() to 
        create a new object. 
    */
    TextAttribute(long inId, Database inDB) throws Exception {
        if (inDB.textAttributeKeyExists(inId)) {
            mDB = inDB;
            mId = inId;
        } else {
            throw new Exception("Key "+inId+" does not exist in database."); // DON'T CHANGE this msg unless you also change the trap for it, if used, in other code.
        }
    }
    /** This one is perhaps only called by the database class implementation--so it can return arrays of objects & save more DB hits
        that would have to occur if it only returned arrays of keys. This DOES NOT create a persistent object--but rather should reflect
        one that already exists.
    */
    TextAttribute(Database inDB, long inParentId, long inId, String inText, long inAttrTypeId, long inDate1, long inDate2) {
        mDB = inDB;
        mParentId = inParentId;
        mId = inId;
        mText = inText;
        mAttrTypeId = inAttrTypeId;
        mValidOnDate = inDate1;
        mObservationDate = inDate2;
        mAlreadyReadData = true;
    }
    
    /** return some string. See comments on QuantityAttribute.getDisplayString regarding the parameters.
    */
    String getDisplayString(int inLengthLimit, Entity parentEntity) throws Exception {
        //TextAttribute t = new TextAttribute(inStringId,inDB);
        String typeName = mDB.getEntityName(getAttrTypeId());
        String typeDisp = typeName + ": ";
        String text = getText();
        if (inLengthLimit != 0 && text.length() > (inLengthLimit - typeDisp.length())) {
            text = text.substring(0, inLengthLimit - typeDisp.length() - 3) + "...";
        }
        return typeDisp + text;
    }
    
    String getText() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mText;
    }
    long getParentId() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mParentId;
    }
    long getAttrTypeId() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mAttrTypeId;
    }
    long getValidOnDate() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mValidOnDate;
    }
    long getObservationDate() throws Exception {
        if (! mAlreadyReadData) { readDataFromDB(); }
        return mObservationDate;
    }
    
    private void readDataFromDB() throws Exception {
        java.util.ArrayList textAttrData = mDB.getTextAttributeData(mId);
        
        mParentId=((Long)textAttrData.get(0)).longValue();
        mText = (String)textAttrData.get(1);
        mAttrTypeId=((Long)textAttrData.get(2)).longValue();
        mValidOnDate=((Long)textAttrData.get(3)).longValue();
        mObservationDate=((Long)textAttrData.get(4)).longValue();
        
        mAlreadyReadData=true;
    }

    
    /** Removes this object from the system. */
    void delete() throws Exception {
        mDB.deleteTextAttribute(mId);
    }
    
    private Database mDB;
    private boolean mAlreadyReadData=false;
    
    /** For descriptions of the meanings of these variables, see the comments 
        on PostgreSQLDatabase.createTextAttribute(...) or createTables().
    */
    private long mParentId;
    //moved to Attribute class:
    //private long mId; // the unique identifier assigned to this object in the database.
    private String mText;
    private long mAttrTypeId;
    private long mValidOnDate;
    private long mObservationDate;
}

